﻿//CdlgDesktop.h
#pragma once
#include "afxdialogex.h"

// CdlgDesktop 对话框

class CdlgDesktop : public CDialog
{
	DECLARE_DYNAMIC(CdlgDesktop)

public:
	CdlgDesktop(CWnd* pParent = nullptr);   // 标准构造函数
	virtual ~CdlgDesktop();

public:
	sockaddr_in m_si;
	// 对话框大小
	CRect m_rc;
	// 监控的屏幕大小
	int m_RemoteScreenWidth;
	int m_RemoteScreenHeight;

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_CDLGDESKTOP };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	virtual BOOL OnInitDialog();
	virtual BOOL DestroyWindow();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnClose();
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
};
