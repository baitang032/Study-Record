﻿//CdlgFileTransfer.h
#pragma once
#include "afxdialogex.h"
#include "CSocket.h"

// CdlgFileTransfer 对话框

class CdlgFileTransfer : public CDialog
{
	DECLARE_DYNAMIC(CdlgFileTransfer)

public:
	CdlgFileTransfer(CWnd* pParent = nullptr);   // 标准构造函数
	virtual ~CdlgFileTransfer();

public:
	sockaddr_in m_si;
	CSocket* m_pCSock;

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = DLG_FILETRANSFER };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

	DECLARE_MESSAGE_MAP()
public:
	CListCtrl m_listFile;
	void InitListFile();
	void UpdateListFile();
	afx_msg void OnLvnItemchangedFile(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnBnClickedSend();
	afx_msg void OnBnClickedRecv();
	virtual BOOL OnInitDialog();
	afx_msg void OnClose();
};
