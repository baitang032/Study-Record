﻿// CdlgFileView.cpp: 实现文件
//


#include "RemoteControl.h"
#include "afxdialogex.h"
#include "CdlgFileView.h"
#include "CRemoteControl.h"


// CdlgFileView 对话框

IMPLEMENT_DYNAMIC(CdlgFileView, CDialogEx)

CdlgFileView::CdlgFileView(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOG1, pParent)
	, m_strCurrentPath(_T(""))
	, m_findtext(_T(""))
{

}

CdlgFileView::~CdlgFileView()
{
}

void CdlgFileView::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, BTN_FILEVIEW, m_listwnd);
	DDX_Text(pDX, IDC_EDIT1, m_strCurrentPath);
	DDX_Control(pDX, FIND_TEXT, m_findshuaxin);
	DDX_Text(pDX, FIND_TEXT, m_findtext);
}


BEGIN_MESSAGE_MAP(CdlgFileView, CDialogEx)
	ON_BN_CLICKED(IDOK, &CdlgFileView::OnBnClickedOk)
	ON_BN_CLICKED(BT_BACK, &CdlgFileView::OnBnClickedBack)
	ON_NOTIFY(NM_DBLCLK, BTN_FILEVIEW, &CdlgFileView::OnDblclkListShowwindow)
	ON_NOTIFY(NM_CLICK, BTN_FILEVIEW, &CdlgFileView::OnClickListShowwindow)
	ON_MESSAGE(WM_REFRESH_DRIVE_LIST, &CdlgFileView::OnRefreshDriveList)
END_MESSAGE_MAP()

LRESULT CdlgFileView::OnRefreshDriveList(WPARAM wParam, LPARAM lParam)
{
	DriveListData* pDriveList = reinterpret_cast<DriveListData*>(wParam);
	if (!pDriveList)
		return 0;

	// 清空列表
	m_listwnd.DeleteAllItems();

	// 插入盘符
	int idx = 0;
	for (const auto& drive : pDriveList->drives)
	{
		m_listwnd.InsertItem(idx, drive);
		m_listwnd.SetItemText(idx, 1, drive); 
		++idx;
	}

	// 释放内存
	delete pDriveList;

	return 0;
}

// CdlgFileView 消息处理程序

void CdlgFileView::OnBnClickedOk()
{
	// TODO: 在此添加控件通知处理程序代码
	//CDialogEx::OnOK();
}


BOOL CdlgFileView::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// TODO:  在此添加额外的初始化

	//listCtrl
	m_listwnd.ModifyStyle(0, LVS_REPORT | LVS_SHOWSELALWAYS);

	m_listwnd.InsertColumn(0, "文件名");
	m_listwnd.InsertColumn(1, "文件路径");

	m_listwnd.SetExtendedStyle(LVS_EX_GRIDLINES |
		LVS_EX_FULLROWSELECT | LVS_EX_FLATSB | LVS_EX_MULTIWORKAREAS
	);

	m_listwnd.SetColumnWidth(0, LVSCW_AUTOSIZE_USEHEADER);
	m_listwnd.SetColumnWidth(1, LVSCW_AUTOSIZE_USEHEADER);
	m_listwnd.SetBkColor(RGB(255, 255, 255));
	m_listwnd.SetTextBkColor(RGB(255, 255, 255));
	
	//获取盘符
	SendDriveListRequest();

	m_listwnd.SetColumnWidth(0, LVSCW_AUTOSIZE_USEHEADER);
	m_listwnd.SetColumnWidth(1, LVSCW_AUTOSIZE_USEHEADER);

	return TRUE;  // return TRUE unless you set the focus to a control
	// 异常: OCX 属性页应返回 FALSE
}

void CdlgFileView::SendDriveListRequest()
{
	// 确保远程地址有效
	if (m_si.sin_addr.S_un.S_addr == 0) {
		AfxMessageBox(_T("远程地址无效"));
		return;
	}

	CRemoteControl::GetDriveList(m_pCSock, m_si);
}



//显示盘符
void CdlgFileView::Show_Disk()
{

	m_listwnd.DeleteAllItems();

	SendDriveListRequest();

	m_listwnd.SetColumnWidth(0, LVSCW_AUTOSIZE_USEHEADER);
	m_listwnd.SetColumnWidth(1, LVSCW_AUTOSIZE_USEHEADER);
}

CString CdlgFileView::GetParentDirectory(const CString& strPath)
{
	CString strParentPath = strPath;

	return strParentPath;
}

void CdlgFileView::OnBnClickedBack()
{
	// 1. 获取当前路径
	m_findshuaxin.GetWindowText(m_strCurrentPath);
	CString strCurrent = m_strCurrentPath;
	strCurrent.TrimRight(_T('\\'));  // 去掉可能的结尾斜杠

	// 2. 判断是否是根目录（如 "C:" 或 "C:\"）
	if (strCurrent.GetLength() == 2 && strCurrent[1] == _T(':'))
	{
		SendDriveListRequest(); // 显示所有盘符
		return;
	}

	// 3. 获取上一级目录路径
	TCHAR szPath[MAX_PATH] = { 0 };
	_tcscpy_s(szPath, strCurrent);

	PathRemoveFileSpec(szPath);  // 去掉最后一级目录或文件名
	CString strParentPath = szPath;

	// 防御性判断
	if (strParentPath.IsEmpty() || strParentPath == strCurrent)
	{
		TRACE(_T("路径为空或未变化，无法返回上一级\n"));
		return;
	}

	// 4. 清空列表
	m_listwnd.DeleteAllItems();

	// 5. 构造发包请求列出上一级目录内容
	std::string stdPath = CT2A(strParentPath.GetString());
	size_t pathLen = stdPath.size() + 1;

	FILECMD_PKG* pPkg = (FILECMD_PKG*)new char[sizeof(FILECMD_PKG) + pathLen];
	memset(pPkg, 0, sizeof(FILECMD_PKG) + pathLen);

	pPkg->m_pt = PT_FILECMD;
	pPkg->m_si = m_si;
	pPkg->m_cmdID = 2;  // 列目录
	pPkg->m_paramLen = (ULONG)pathLen;
	memcpy((char*)(pPkg + 1), stdPath.c_str(), pathLen);

	m_pCSock->SendData(PT_FILECMD, m_si, (char*)pPkg, sizeof(FILECMD_PKG) + pathLen);
	
	// 6. 更新路径显示
	m_findshuaxin.SetWindowText(strParentPath);
}



void CdlgFileView::OnDblclkListShowwindow(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);

	int nSelId = m_listwnd.GetSelectionMark();
	if (nSelId != -1)
	{
		CString strPath = m_listwnd.GetItemText(nSelId, 1); // 第二列是路径

		// 转为 std::string
		std::string stdPath = CT2A(strPath.GetString());

		// 构造 FILECMD_PKG
		size_t pathLen = stdPath.size(); // 包含末尾 \0
		FILECMD_PKG* pPkg = (FILECMD_PKG*)new char[sizeof(FILECMD_PKG) + pathLen];
		memset(pPkg, 0, sizeof(FILECMD_PKG) + pathLen);

		pPkg->m_pt = PT_FILECMD;
		pPkg->m_si = m_si;           // 控制端自己的地址
		pPkg->m_cmdID = 2;           // 列目录
		pPkg->m_paramLen = (ULONG)pathLen;
		memcpy((char*)(pPkg + 1), stdPath.c_str(), pathLen);

		// 清空旧数据
		m_listwnd.DeleteAllItems();

		// 发送请求
		m_pCSock->SendData(PT_FILECMD, m_si, (char*)pPkg, sizeof(FILECMD_PKG) + pathLen);

		
	}

	*pResult = 0;
}


void CdlgFileView::OnClickListShowwindow(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: 在此添加控件通知处理程序代码

	int nSelId = m_listwnd.GetSelectionMark();
	if (nSelId != -1)
	{
		// 从该项中获取路径信息
		CString strItemPath = m_listwnd.GetItemText(nSelId, 1); // 假设路径在第二列

		// 将路径信息设置到 m_findtext 变量中
		m_findtext = strItemPath;

		// 更新对话框中的 FIND_TEXT 控件
		m_findshuaxin.SetWindowText(m_findtext);
	}

	*pResult = 0;
}