//CSocket.cpp
#include "CSocket.h"
#include "RemoteControl.h"
#include "RemoteControlDlg.h"

CSocket::CSocket()
{
	m_mpClients = new map<sockaddr_in, tuple<sockaddr_in, SOCKET, sockaddr_in, SOCKET>, sockaddr_in_compare>{};
	m_quSendData = new queue<PACKAGE*>{};
	m_quRecvData = new queue<PACKAGE*>{};
	m_quSendFile = new queue<FILEPKG*>{};
	m_quRecvFile = new queue<FILEPKG*>{};
	m_mpFileInfo = new map<string, pair<LARGE_INTEGER, LARGE_INTEGER>>{};

	m_sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (m_sock == INVALID_SOCKET)
	{
		OutputDebugString("socket failed");
		return;
	}
	m_sockFile = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (m_sockFile == INVALID_SOCKET)
	{
		OutputDebugString("socket failed");
		return;
	}
}

CSocket::CSocket(const char* IP, USHORT port, USHORT portFile, bool isServer)
{
	m_mpClients = new map<sockaddr_in, tuple<sockaddr_in, SOCKET, sockaddr_in, SOCKET>, sockaddr_in_compare>{};
	m_quSendData = new queue<PACKAGE*>{};
	m_quRecvData = new queue<PACKAGE*>{};
	m_quSendFile = new queue<FILEPKG*>{};
	m_quRecvFile = new queue<FILEPKG*>{};
	m_mpFileInfo = new map<string, pair<LARGE_INTEGER, LARGE_INTEGER>>{};

	m_bIsServer = isServer;
	m_sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (m_sock == INVALID_SOCKET)
	{
		OutputDebugString("socket failed");
		return;
	}
	m_sockFile = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (m_sockFile == INVALID_SOCKET)
	{
		OutputDebugString("socket failed");
		return;
	}

	// �󶨶˿�
	m_si = { AF_INET };
	m_si.sin_port = htons(port);
	m_si.sin_addr.S_un.S_addr = inet_addr(IP);
	::bind(m_sock, (sockaddr*)&m_si, sizeof(m_si));
	m_siFile = { AF_INET };
	m_siFile.sin_port = htons(portFile);
	m_siFile.sin_addr.S_un.S_addr = inet_addr(IP);
	::bind(m_sockFile, (sockaddr*)&m_siFile, sizeof(m_siFile));

	if (m_bIsServer)
	{
		// ����
		if (listen(m_sock, SOMAXCONN) == SOCKET_ERROR)
		{
			OutputDebugString("linsten failed");
			return;
		}
		if (listen(m_sockFile, SOMAXCONN) == SOCKET_ERROR)
		{
			OutputDebugString("linsten failed");
			return;
		}
		// ����������Ϣ�߳�
		thread t1(&CSocket::SendThread, this);
		t1.detach();
		// ����������Ϣ�߳�
		thread t2(&CSocket::SendFileThread, this);
		t2.detach();

		// ����һ�������߳�
		thread t(&CSocket::acceptThread, this);
		t.detach();
	}
}

CSocket::~CSocket()
{
	delete m_mpClients;
	delete m_quSendData;
	delete m_quRecvData;
	delete m_quSendFile;
	delete m_quRecvFile;
	delete m_mpFileInfo;
	// �ر��׽���
	shutdown(m_sock, 0);
	closesocket(m_sock);
	shutdown(m_sockFile, 0);
	closesocket(m_sockFile);
}

void CSocket::SetAddr(const char* IP, USHORT port, USHORT portFile, bool isServer)
{
	m_bIsServer = isServer;
	m_sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (m_sock == INVALID_SOCKET)
	{
		OutputDebugString("socket failed");
		return;
	}
	m_sockFile = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (m_sockFile == INVALID_SOCKET)
	{
		OutputDebugString("socket failed");
		return;
	}

	// �󶨶˿�
	m_si = { AF_INET };
	m_si.sin_port = htons(port);
	m_si.sin_addr.S_un.S_addr = inet_addr(IP);
	::bind(m_sock, (sockaddr*)&m_si, sizeof(m_si));
	m_siFile = { AF_INET };
	m_siFile.sin_port = htons(portFile);
	m_siFile.sin_addr.S_un.S_addr = inet_addr(IP);
	::bind(m_sockFile, (sockaddr*)&m_siFile, sizeof(m_siFile));

	if (m_bIsServer)
	{
		// ����
		if (listen(m_sock, SOMAXCONN) == SOCKET_ERROR)
		{
			OutputDebugString("linsten failed");
			return;
		}
		if (listen(m_sockFile, SOMAXCONN) == SOCKET_ERROR)
		{
			OutputDebugString("linsten failed");
			return;
		}

		// ����������Ϣ�߳�
		thread t1(&CSocket::SendThread, this);
		t1.detach();
		// ���������ļ��߳�
		thread t2(&CSocket::SendFileThread, this);
		t2.detach();

		// ����һ�������߳�
		thread t(&CSocket::acceptThread, this);
		t.detach();
	}
}

void CSocket::Connect(const char* IP, USHORT port, USHORT portFile)
{
	// ���ӷ�����
	m_siDistance = { AF_INET };
	m_siDistance.sin_port = htons(port);
	m_siDistance.sin_addr.S_un.S_addr = inet_addr(IP);
	int nRet = connect(m_sock, (sockaddr*)&m_siDistance, sizeof(m_siDistance));
	if (nRet == SOCKET_ERROR)
	{
		OutputDebugString(GetMyError("connect").c_str());
	}
	m_siFileDistance = { AF_INET };
	m_siFileDistance.sin_port = htons(portFile);
	m_siFileDistance.sin_addr.S_un.S_addr = inet_addr(IP);
	nRet = connect(m_sockFile, (sockaddr*)&m_siFileDistance, sizeof(m_siFileDistance));
	if (nRet == SOCKET_ERROR)
	{
		OutputDebugString(GetMyError("connect").c_str());
	}

	// ����������Ϣ�߳�
	thread t1(&CSocket::SendThread, this);
	t1.detach();
	// ����������Ϣ�߳�
	thread t2(&CSocket::SendFileThread, this);
	t2.detach();

	// ����������Ϣ�߳�
	thread t(&CSocket::recvThread, this, m_siDistance);
	t.detach();
	thread t3(&CSocket::recvFileThread, this, m_siFileDistance);
	t3.detach();
}

void CSocket::acceptThread()
{
	while (!m_bStopThread)
	{
		// ��������
		SOCKET sockClient = INVALID_SOCKET;
		sockaddr_in siClient{};
		int nLen = sizeof(siClient);
		sockClient = accept(m_sock, (sockaddr*)&siClient, &nLen);
		if (sockClient == INVALID_SOCKET)
		{
			OutputDebugString("accept failed");
			return;
		}
		SOCKET sockFileClient = INVALID_SOCKET;
		sockaddr_in siFileClient{};
		nLen = sizeof(siFileClient);
		sockFileClient = accept(m_sockFile, (sockaddr*)&siFileClient, &nLen);
		if (sockFileClient == INVALID_SOCKET)
		{
			OutputDebugString("accept failed");
			return;
		}
		// �洢���ӿͻ���
		m_mtClients.lock();
		m_mpClients->emplace(siClient, make_tuple(siClient, sockClient, siFileClient, sockFileClient));
		m_mtClients.unlock();
#ifdef SERVER
		// ���������б�
		((CRemoteControlDlg*)(AfxGetApp()->m_pMainWnd))->UpDataListCtrl();
#endif // SERVER

		// ����һ�����ոÿͻ������ݵ��߳�
		thread t(&CSocket::recvThread, this, siClient);
		t.detach();
		thread t1(&CSocket::recvFileThread, this, siFileClient);
		t1.detach();
	}
}


void CSocket::SendData(PKG_TYPE pt, sockaddr_in si, char* data, size_t nSize)
{
	if (data == nullptr)
	{
		m_mtSendData.lock();
		PACKAGE* pkg = new PACKAGE(pt, si);
		m_quSendData->push(pkg);
		m_mtSendData.unlock();

		if (data != nullptr)
		{
			delete[] data;
			data = nullptr;
		}
		return;
	}

	// �����͵�������Ƭ�����뷢�Ͷ���
	int nCnt = nSize / MAXDATA;
	for (size_t i = 0; i < nCnt + 1; i++)
	{
		if (i == nCnt)
		{
			if (nSize % MAXDATA == 0)
			{
				break;
			}
			m_mtSendData.lock();
			PACKAGE* pkg = new PACKAGE(pt, si, data + i * MAXDATA, nSize % MAXDATA);
			m_quSendData->push(pkg);
			m_mtSendData.unlock();
			break;
		}
		m_mtSendData.lock();
		PACKAGE* pkg = new PACKAGE(pt, si, data + i * MAXDATA, MAXDATA);
		m_quSendData->push(pkg);
		m_mtSendData.unlock();
	}

	if (data != nullptr)
	{
		delete[] data;
		data = nullptr;
	}
}

void CSocket::SendFile(PKG_TYPE pt, sockaddr_in si, char* szFileName, int nFileNameLen, char* data, size_t nDataSize)
{
	size_t nCnt = (nDataSize + MAXDATA - 1) / MAXDATA;
	for (size_t i = 0; i < nCnt; i++)
	{
		size_t offset = i * MAXDATA;
		size_t chunkSize = min(MAXDATA, nDataSize - offset); // ��ȷ����ÿ���С

		LARGE_INTEGER li = {};
		li.QuadPart = offset;
		FILEPKG* pFilePkg = new FILEPKG(pt, si, li, szFileName, nFileNameLen, data + offset, chunkSize);


		std::lock_guard<std::mutex> lock(m_mtSendFile);
		m_quSendFile->push(pFilePkg);
	}

}


void CSocket::recvThread(sockaddr_in si)
{
	// ��������
	while (!m_bStopThread)
	{
		PACKAGE* pkg = RecvPkg(si);
		if (pkg == nullptr)
		{
			// �Ͽ�����
#ifdef SERVER
			// ���������б�
			((CRemoteControlDlg*)(AfxGetApp()->m_pMainWnd))->UpDataListCtrl();
#endif // SERVER
			return;
		}

		// ���������������
		m_mtRecvData.lock();
		m_quRecvData->push(pkg);
		m_mtRecvData.unlock();
	}
}

void CSocket::recvFileThread(sockaddr_in si)
{
	// ��������
	while (!m_bStopThread)
	{
		FILEPKG* pFilePkg = RecvFile(si);
		if (pFilePkg == nullptr)
		{
			// �Ͽ�����
			return;
		}

		// ���������������
		m_mtRecvFile.lock();
		m_quRecvFile->push(pFilePkg);
		m_mtRecvFile.unlock();
	}
}

void CSocket::SendThread()
{
	while (!m_bStopThread)
	{
		// ���Ͷ��в�Ϊ��
		if (!m_quSendData->empty())
		{
			m_mtSendData.lock();
			PACKAGE* pkg = m_quSendData->front();
			m_quSendData->pop();
			m_mtSendData.unlock();

			SOCKET sock = INVALID_SOCKET;
			// �������ݰ�
			if (m_bIsServer)
			{
				if (m_mpClients->find(pkg->m_si) == m_mpClients->end())
				{
					continue;
				}
				m_mtClients.lock();
				sock = get<1>(m_mpClients->find(pkg->m_si)->second);
				m_mtClients.unlock();
			}
			else
			{
				sock = m_sock;
			}

			// ���Լ���IP��ַ�Ͷ˿ںŷ���
			pkg->m_si = m_si;
			char* pBuf = new char[pkg->size()] {};
			memcpy(pBuf, pkg, pkg->size() - pkg->m_wsabuf.len);
			memcpy(pBuf + pkg->size() - pkg->m_wsabuf.len, pkg->m_wsabuf.buf, pkg->m_wsabuf.len);
			if (SOCKET_ERROR == send(sock, pBuf, pkg->size(), 0))
			{
				OutputDebugString(GetMyError("send").c_str());
			}
			delete[] pBuf;
			delete pkg;
			pBuf = nullptr;
			pkg = nullptr;
		}
	}
}

void CSocket::SendFileThread()
{
	while (!m_bStopThread)
	{
		// �����ļ�
		if (!m_quSendFile->empty())
		{
			m_mtSendFile.lock();
			FILEPKG* pFilePkg = m_quSendFile->front();
			m_quSendFile->pop();
			m_mtSendFile.unlock();

			SOCKET sockFile = INVALID_SOCKET;
			// �������ݰ�
			if (m_bIsServer)
			{
				m_mtClients.lock();
				for (auto& pr : *m_mpClients)
				{
					if (memcmp(&get<2>(pr.second), &pFilePkg->m_FileHead.m_si, sizeof(sockaddr_in)) == 0)
					{
						sockFile = get<3>(pr.second);
						break;
					}
				}
				m_mtClients.unlock();
			}
			else
			{
				sockFile = m_sockFile;
			}

			// ���Լ���IP��ַ�Ͷ˿ںŷ���
			pFilePkg->m_FileHead.m_si = m_siFile;
			// �����ݿ�������ʱ������
			char* pBuf = new char[pFilePkg->size()] {};
			memcpy(pBuf, pFilePkg, sizeof(FILEPKGHEAD));
			memcpy(pBuf + sizeof(FILEPKGHEAD), pFilePkg->m_FileName, pFilePkg->m_FileHead.m_FileNameLen);
			memcpy(pBuf + sizeof(FILEPKGHEAD) + pFilePkg->m_FileHead.m_FileNameLen, pFilePkg->m_FileData, pFilePkg->m_FileHead.m_FileSize);


			if (SOCKET_ERROR == send(sockFile, pBuf, pFilePkg->size(), 0))
			{
				OutputDebugString(GetMyError("sendFile").c_str());
			}
			delete[] pBuf;
			delete pFilePkg;
			pBuf = nullptr;
			pFilePkg = nullptr;
		}
	}
}

size_t CSocket::RecvNumPkg(sockaddr_in si, char* szBuf, size_t nSize)
{
	SOCKET sock = INVALID_SOCKET;
	size_t RecvCnt = 0;
	while (RecvCnt < nSize)
	{
		if (m_bIsServer)
		{
			m_mtClients.lock();
			sock = get<1>(m_mpClients->find(si)->second);
			m_mtClients.unlock();
		}
		else
		{
			sock = m_sock;
		}
		size_t nRet = recv(sock, szBuf + RecvCnt, nSize - RecvCnt, 0);
		if (nRet == 0)
		{
			OutputDebugString(GetMyError("���������Ͽ�").c_str());
			// ���������ر�
			m_mtClients.lock();
			m_mpClients->erase(si);
			m_mtClients.unlock();
			return -1;
		}
		if (nRet == SOCKET_ERROR)
		{
			OutputDebugString(GetMyError("recv").c_str());
			// ����
			m_mtClients.lock();
			m_mpClients->erase(si);
			m_mtClients.unlock();
			return -1;
		}
		RecvCnt += nRet;
	}
	return RecvCnt;
}

PACKAGE* CSocket::RecvPkg(sockaddr_in si)
{
	// ���հ�ͷ
	size_t uHandSize = sizeof(PKG_TYPE) + sizeof(sockaddr_in) + sizeof(WSABUF);
	char* szHander = new char[uHandSize] {};
	if (RecvNumPkg(si, szHander, uHandSize) == -1)
	{
		delete[] szHander;
		szHander = nullptr;
		return nullptr;
	}

	PACKAGE* pkgHead = (PACKAGE*)szHander;
	// ���հ���
	PACKAGE* pkg = new PACKAGE(pkgHead->m_wsabuf.len);
	pkg->m_pt = pkgHead->m_pt;
	pkg->m_si = pkgHead->m_si;
	pkg->m_wsabuf.len = pkgHead->m_wsabuf.len;
	if (pkgHead->m_wsabuf.len > 0)
	{
		if (RecvNumPkg(si, pkg->m_wsabuf.buf, pkgHead->m_wsabuf.len) == -1)
		{
			delete[] szHander;
			szHander = nullptr;
			return nullptr;
		}
	}
	pkg->m_si = si;
	delete[] szHander;
	szHander = nullptr;
	return pkg;
}

size_t CSocket::RecvNumFile(sockaddr_in si, char* szBuf, size_t nSize)
{
	SOCKET sockFile = INVALID_SOCKET;
	size_t RecvCnt = 0;
	while (RecvCnt < nSize)
	{
		if (m_bIsServer)
		{
			m_mtClients.lock();
			for (auto& pr : *m_mpClients)
			{
				if (memcmp(&get<2>(pr.second), &si, sizeof(sockaddr_in)) == 0)
				{
					sockFile = get<3>(pr.second);
					break;
				}
			}
			m_mtClients.unlock();
		}
		else
		{
			sockFile = m_sockFile;
		}
		size_t nRet = recv(sockFile, szBuf + RecvCnt, nSize - RecvCnt, 0);
		if (nRet == 0)
		{
			OutputDebugString(GetMyError("�ļ����������Ͽ�").c_str());
			return -1;
		}
		if (nRet == SOCKET_ERROR)
		{
			OutputDebugString(GetMyError("recvFile").c_str());
			return -1;
		}
		RecvCnt += nRet;
	}
	return RecvCnt;
}

FILEPKG* CSocket::RecvFile(sockaddr_in si)
{
	// ���հ�ͷ
	size_t uHandSize = sizeof(FILEPKGHEAD);
	char* szHander = new char[uHandSize] {};
	if (RecvNumFile(si, szHander, uHandSize) == -1)
	{
		delete[] szHander;
		szHander = nullptr;
		return nullptr;
	}

	FILEPKGHEAD* pkgHead = (FILEPKGHEAD*)szHander;
	// ���հ���
	FILEPKG* pFilePkg = new FILEPKG(*pkgHead);
	if (pFilePkg->m_FileHead.m_FileNameLen > 0)
	{
		if (RecvNumFile(si, pFilePkg->m_FileName, pFilePkg->m_FileHead.m_FileNameLen) == -1)
		{
			delete[] szHander;
			szHander = nullptr;
			return nullptr;
		}
	}	
	if (pFilePkg->m_FileHead.m_FileSize > 0)
	{
		if (RecvNumFile(si, pFilePkg->m_FileData, pFilePkg->m_FileHead.m_FileSize) == -1)
		{
			delete[] szHander;
			szHander = nullptr;
			return nullptr;
		}
	}
	delete[] szHander;
	szHander = nullptr;
	return pFilePkg;
}
