﻿// CdlgFileTransfer.cpp: 实现文件
//


#include "RemoteControl.h"
#include "afxdialogex.h"
#include "CdlgFileTransfer.h"

#include "CRemoteControl.h"
#include "RemoteControlDlg.h"

// CdlgFileTransfer 对话框

IMPLEMENT_DYNAMIC(CdlgFileTransfer, CDialog)

CdlgFileTransfer::CdlgFileTransfer(CWnd* pParent /*=nullptr*/)
	: CDialog(DLG_FILETRANSFER, pParent)
{

}

CdlgFileTransfer::~CdlgFileTransfer()
{
}

void CdlgFileTransfer::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, LIST_FILE, m_listFile);
}


BEGIN_MESSAGE_MAP(CdlgFileTransfer, CDialog)
	ON_NOTIFY(LVN_ITEMCHANGED, LIST_FILE, &CdlgFileTransfer::OnLvnItemchangedFile)
	ON_BN_CLICKED(BTN_SEND, &CdlgFileTransfer::OnBnClickedSend)
	ON_BN_CLICKED(BTN_RECV, &CdlgFileTransfer::OnBnClickedRecv)
	ON_WM_CLOSE()
END_MESSAGE_MAP()


// CdlgFileTransfer 消息处理程序


void CdlgFileTransfer::InitListFile()
{
	// 初始化主机列表
	m_listFile.InsertColumn(0, "文件名");
	m_listFile.InsertColumn(1, "文件大小");
	m_listFile.InsertColumn(2, "进度");

	// 设置列宽
	CRect rc;
	m_listFile.GetWindowRect(&rc);
	int width = rc.Width() / 5;
	m_listFile.SetColumnWidth(0, width * 3);
	m_listFile.SetColumnWidth(1, width);
	m_listFile.SetColumnWidth(2, width);

	// 设置样式
	m_listFile.SetExtendedStyle(LVS_EX_GRIDLINES | LVS_EX_FULLROWSELECT);
}

void CdlgFileTransfer::UpdateListFile()
{
	// 清空列表
	m_listFile.DeleteAllItems();

	// 将文件信息填入列表
	std::lock_guard<std::recursive_mutex> lock(m_pCSock->m_mtFileInfo);
	int i = 0;
	for (auto& pr : *m_pCSock->m_mpFileInfo)
	{
		CString fmt;
		m_listFile.InsertItem(i, pr.first.c_str());
		fmt.Format("%lld", pr.second.first.QuadPart);
		m_listFile.SetItemText(i, 1, fmt);
		fmt.Format("%lld", pr.second.second.QuadPart);
		m_listFile.SetItemText(i, 2, fmt);
		m_listFile.SetItemData(i, (DWORD_PTR)&pr.first);
		i++;
	}

}


void CdlgFileTransfer::OnLvnItemchangedFile(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMLISTVIEW pNMLV = reinterpret_cast<LPNMLISTVIEW>(pNMHDR);
	// TODO: 在此添加控件通知处理程序代码
	*pResult = 0;
}


void CdlgFileTransfer::OnBnClickedSend()
{
	// 发送文件到客户端
	CString strPath;
	GetDlgItemText(EDIT_FILESEND, strPath);
	char* p = new char[strPath.GetLength()] {};
	memcpy(p, strPath.GetString(), strPath.GetLength());
	m_pCSock->SendData(PT_DOWNFILE, m_si, p, strPath.GetLength());
}


void CdlgFileTransfer::OnBnClickedRecv()
{
	// 让客户端把文件发过来
	CString strPath;
	GetDlgItemText(EDIT_FILERECV, strPath);
	char* p = new char[strPath.GetLength()] {};
	memcpy(p, strPath.GetString(), strPath.GetLength());
	m_pCSock->SendData(PT_UPFILE, m_si, p, strPath.GetLength());
}


BOOL CdlgFileTransfer::OnInitDialog()
{
	CDialog::OnInitDialog();

	// 初始化文件列表
	m_pCSock = &((CRemoteControlDlg*)AfxGetMainWnd())->m_CSock;
	InitListFile();	

	return TRUE;  // return TRUE unless you set the focus to a control
	// 异常: OCX 属性页应返回 FALSE
}


void CdlgFileTransfer::OnClose()
{
	((CRemoteControlDlg*)(AfxGetApp()->m_pMainWnd))->DestoryDlg(m_si, PT_TRANSFEREND);
}
