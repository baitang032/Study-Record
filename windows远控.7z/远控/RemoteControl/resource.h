﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 RemoteControl.rc 使用
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_REMOTECONTROL_DIALOG        102
#define IDD_CDLGDESKTOP                 103
#define IDD_CControlCMD                 104
#define IDR_MAINFRAME                   128
#define DLG_FILETRANSFER                132
#define IDD_DIALOG1                     135
#define IDC_LIST1                       1000
#define LIST_HOST                       1000
#define LIST_FILE                       1000
#define EDIT_SENDCMD                    1001
#define BTN_SEND                        1002
#define EDIT_RECVCMD                    1003
#define BTN_RECV                        1005
#define IDC_MFCEDITBROWSE1              1006
#define EDIT_FILESEND                   1006
#define IDC_MFCVSLISTBOX1               1008
#define EDIT_FILERECV                   1009
#define BTN_FILEVIEW                    1010
#define BT_BACK                         1011
#define IDC_EDIT1                       1012
#define FIND_TEXT                       1012
#define ID_32771                        32771
#define ID_32772                        32772
#define RBTN_RE                         32773
#define RBTN_SCREEN                     32774
#define RBTN_CMD                        32775
#define ID_32776                        32776
#define RBTN_FILE                       32777
#define RBTN_FILETRANSFER               32778
#define MENU_RBTN                       32779
#define ID_32780                        32780
#define RBTN_FILEVIEW                   32781
#define ID_32782                        32782

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32783
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
