﻿//CControlCMD.h
#pragma once
#include "afxdialogex.h"


// CControlCMD 对话框

class CControlCMD : public CDialog
{
	DECLARE_DYNAMIC(CControlCMD)

public:
	CControlCMD(CWnd* pParent = nullptr);   // 标准构造函数
	virtual ~CControlCMD();

public:
	sockaddr_in m_si;

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_CControlCMD };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL DestroyWindow();
	afx_msg void OnBnClickedSend();
	virtual BOOL OnInitDialog();
	CEdit m_CEditDisplay;
	afx_msg void OnClose();
};
