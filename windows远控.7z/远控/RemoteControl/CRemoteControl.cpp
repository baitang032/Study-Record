//CRemoteControl.cpp ʵ���ļ�
#include <string>

#include "CSocket.h"
#include "CRemoteControl.h"

void CRemoteControl::SendDesktop(CSocket* CSock)
{
	// ��ȡ����DC
	HDC hdc = GetDC(NULL);
	if (hdc == NULL)
	{
		OutputDebugString(GetMyError("GetDC").c_str());
		return;
	}

	// �����ڴ�DC
	HDC hmem = CreateCompatibleDC(NULL);
	if (hmem == NULL)
	{
		OutputDebugString(GetMyError("CreateCompatibleDC").c_str());
		return;
	}

	int width = GetSystemMetrics(SM_CXSCREEN);
	int height = GetSystemMetrics(SM_CYSCREEN);
	int pixelBits = GetDeviceCaps(hdc, BITSPIXEL) / 8;

	// �����ڴ�λͼ
	HBITMAP hbm = CreateCompatibleBitmap(hdc, width, height);
	if (hbm == NULL)
	{
		OutputDebugString(GetMyError("CreateCompatibleBitmap").c_str());
		return;
	}
	SelectObject(hmem, hbm);

	// ����λͼ���ڴ�DC
	if (BitBlt(hmem, 0, 0, width, height, hdc, 0, 0, SRCCOPY) == 0)
	{
		OutputDebugString(GetMyError("BitBlt").c_str());
		return;
	}

	// ׼��������
	ULONG nBufSize = sizeof(width) + sizeof(height) + width * height * pixelBits;
	char* pBuffer = new char[nBufSize] {};
	char* p = pBuffer;

	// д�����
	*(int*)p = width; p += sizeof(width);
	*(int*)p = height; p += sizeof(height);

	// д���ڴ�λͼ����
	int n = GetBitmapBits(hbm, width * height * pixelBits, p);
	if (n == 0)
	{
		OutputDebugString(GetMyError("GetBitmapBits").c_str());
		return;
	}

	// ����
	CSock->SendData(PT_SCREEN, CSock->m_si, pBuffer, nBufSize);

	DeleteObject(hbm);
	DeleteDC(hmem);
	DeleteDC(hdc);
}

void CRemoteControl::Cmd(CSocket* CSock, sockaddr_in si, char* buf, ULONG nlen)
{
	if (nlen == 0)
	{
		CSock->SendData(PT_CMD, si);
		return;
	}
	// ��������������
	char* pBuffer = new char[nlen] {};
	memcpy(pBuffer, buf, nlen);
	CSock->SendData(PT_CMD, si, pBuffer, nlen);
}

void CRemoteControl::UploadFile(CSocket* CSock, sockaddr_in si, sockaddr_in siFile, char* szFileName, int nFileNameLen)
{
	// ʹ���ļ�ӳ��ķ�ʽ�ϴ��ļ�
	string strFileName(szFileName, nFileNameLen);
	HANDLE hFile = CreateFile(strFileName.c_str(),
		GENERIC_READ,
		FILE_SHARE_READ,
		NULL,
		OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL,
		NULL);
	if (hFile == INVALID_HANDLE_VALUE)
	{
		string strError = GetMyError("CreateFile failed");
		OutputDebugString(strError.c_str());
		// �ļ�������ȷ
		char* p = new char[strError.size()];
		memcpy(p, strError.c_str(), strError.size());
		CSock->SendData(PT_NONE, si, p, strError.size());
		return;
	}

	// �����ļ�ӳ�����
	HANDLE hFileMap = CreateFileMapping(hFile,
		NULL,
		PAGE_READONLY,
		0, 0,
		NULL);
	if (hFileMap == nullptr)
	{
		string strError = GetMyError("CreateFileMapping failed");
		OutputDebugString(strError.c_str());
		// �ļ�������ȷ
		char* p = new char[strError.size()];
		memcpy(p, strError.c_str(), strError.size());
		CSock->SendData(PT_NONE, si, p, strError.size());
		return;
	}

	// ��ȡ�ļ�����
	SYSTEM_INFO SysInfo = {};
	GetSystemInfo(&SysInfo);
	// ����ӳ�䵽�ڴ��С
	LARGE_INTEGER liReadMemSize = { SysInfo.dwPageSize * 50000 };

	// ��ȡ�ļ���С
	LARGE_INTEGER liFileSize = {};
	GetFileSizeEx(hFile, &liFileSize);
	// �ļ�ƫ��
	LARGE_INTEGER liFileOffset = {};
	// �ļ�����
	LPVOID pBuffer = nullptr;
	// �ļ�ƫ�ƴ���
	size_t nCnt = liFileSize.QuadPart / liReadMemSize.QuadPart;

	// �ļ���ʼ���䡢�����ļ������ļ���С
	FILEINFO fi(nFileNameLen, liFileSize, szFileName);
	char* pbufBegin = new char[fi.size()];
	char* p = pbufBegin;
	*(size_t*)p = fi.m_nFileNameLen; p += sizeof(size_t);
	*(LARGE_INTEGER*)p = fi.m_liFileSize; p += sizeof(LARGE_INTEGER);
	memcpy(p, fi.m_szFileName, fi.m_nFileNameLen);
	CSock->SendData(PT_TRANSFERSTART, si, pbufBegin, sizeof(fi.m_nFileNameLen) + fi.m_nFileNameLen + sizeof(liFileSize));

	for (size_t i = 0; i < nCnt + 1; i++)
	{
		if (i == nCnt)
		{
			// ӳ�䵽�ڴ�
			liFileOffset.QuadPart = i * liReadMemSize.QuadPart;
			// ʣ���С
			LARGE_INTEGER liFileEndSize = { liFileSize.QuadPart % liReadMemSize.QuadPart };
			pBuffer = MapViewOfFile(hFileMap, FILE_MAP_READ, liFileOffset.HighPart, liFileOffset.LowPart, liFileEndSize.QuadPart);
			if (pBuffer == nullptr)
			{
				string strError = GetMyError("MapViewOfFile failed");
				OutputDebugString(strError.c_str());
				// �ļ�������ȷ
				char* p = new char[strError.size()];
				memcpy(p, strError.c_str(), strError.size());
				CSock->SendData(PT_NONE, si, p, strError.size());
				return;
			}
			// �����ļ�
			CSock->SendFile(PT_UPFILE, siFile, szFileName, nFileNameLen, (char*)pBuffer, liFileEndSize.QuadPart);

			// ���ͽ���
			FILEINFO fiEnd(nFileNameLen, liFileEndSize, szFileName);
			char* pEnd = new char[fi.size()];
			char* p = pEnd;
			*(size_t*)p = fi.m_nFileNameLen; p += sizeof(size_t);
			*(LARGE_INTEGER*)p = fi.m_liFileSize; p += sizeof(LARGE_INTEGER);
			memcpy(p, fi.m_szFileName, fi.m_nFileNameLen);
			CSock->SendData(PT_TRANSFER, si, pEnd, sizeof(fi.m_nFileNameLen) + fi.m_nFileNameLen + sizeof(liFileSize));

			// ȡ���ļ�ӳ��
			UnmapViewOfFile(pBuffer);
			break;
		}
		// ӳ�䵽�ڴ�
		liFileOffset.QuadPart = i * liReadMemSize.QuadPart;
		pBuffer = MapViewOfFile(hFileMap, FILE_MAP_READ, liFileOffset.HighPart, liFileOffset.LowPart, liReadMemSize.QuadPart);
		if (pBuffer == nullptr)
		{
			string strError = GetMyError("MapViewOfFile failed");
			OutputDebugString(strError.c_str());
			// �ļ�������ȷ
			char* p = new char[strError.size()];
			memcpy(p, strError.c_str(), strError.size());
			CSock->SendData(PT_NONE, si, p, strError.size());
			return;
		}
		// ��������
		CSock->SendFile(PT_UPFILE, siFile, szFileName, nFileNameLen, (char*)pBuffer, liReadMemSize.QuadPart);

		// ���ͽ���
		FILEINFO fiTrans(nFileNameLen, liReadMemSize, szFileName);
		char* pTrans = new char[fi.size()];
		char* p = pTrans;
		*(size_t*)p = fi.m_nFileNameLen; p += sizeof(size_t);
		*(LARGE_INTEGER*)p = fi.m_liFileSize; p += sizeof(LARGE_INTEGER);
		memcpy(p, fi.m_szFileName, fi.m_nFileNameLen);
		CSock->SendData(PT_TRANSFER, si, pTrans, sizeof(fi.m_nFileNameLen) + fi.m_nFileNameLen + sizeof(liFileSize));

		// ȡ���ļ�ӳ��
		UnmapViewOfFile(pBuffer);
	}

	// �ļ��������
	FILEINFO fiEnd(nFileNameLen, liFileSize, szFileName);
	char* pEnd = new char[fi.size()];
	p = pEnd;
	*(size_t*)p = fi.m_nFileNameLen; p += sizeof(size_t);
	*(LARGE_INTEGER*)p = fi.m_liFileSize; p += sizeof(LARGE_INTEGER);
	memcpy(p, fi.m_szFileName, fi.m_nFileNameLen);
	CSock->SendData(PT_TRANSFEREND, si, pEnd, sizeof(fi.m_nFileNameLen) + fi.m_nFileNameLen + sizeof(liFileSize));

	// �ر��ļ�ӳ�����
	CloseHandle(hFileMap);
	// �ر��ļ�
	CloseHandle(hFile);
}

void CRemoteControl::DownloadFile(CSocket* CSock)
{
	// �����ļ�ӳ����������ļ����
	map<string, pair<HANDLE, HANDLE>> mpFileMap;
	// �����ļ�����
	while (!CSock->m_bStopThread)
	{
		if (!CSock->m_quRecvFile->empty())
		{
			CSock->m_mtRecvFile.lock();
			FILEPKG* pFilePkg = CSock->m_quRecvFile->front();
			CSock->m_quRecvFile->pop();
			CSock->m_mtRecvFile.unlock();

			string strFileName;
			string strFilePath = string(pFilePkg->m_FileName, pFilePkg->m_FileHead.m_FileNameLen);
			size_t nIdx = strFilePath.find_last_of('\\');
			if (nIdx == string::npos)
			{
				strFileName += strFilePath;
			}
			else
			{
				strFileName += strFilePath.substr(nIdx + 1, strFilePath.size() - nIdx);
			}

			// �����ǰ�ļ�û�д���ӳ�����
			if (mpFileMap.find(strFilePath) == mpFileMap.end())
			{
				// ������ǰ�ļ�ӳ����󲢱��桢�����ļ�����ǰ·��
				HANDLE hFile = CreateFile(strFileName.c_str(), GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
				if (hFile == INVALID_HANDLE_VALUE)
				{
					string strError = GetMyError("CreateFile failed");
					OutputDebugString(strError.c_str());
					// �ļ�������ȷ
					char* p = new char[strError.size()];
					memcpy(p, strError.c_str(), strError.size());
					CSock->SendData(PT_NONE, CSock->m_si, p, strError.size());
					continue;
				}
				LARGE_INTEGER liFileSize = ((*(CSock->m_mpFileInfo))[strFilePath]).first;
				HANDLE hFileMap = CreateFileMapping(hFile, NULL, PAGE_READWRITE, liFileSize.HighPart, liFileSize.LowPart, NULL);
				if (hFileMap == NULL)
				{
					string strError = GetMyError("CreateFileMapping failed");
					OutputDebugString(strError.c_str());
					// �ļ�������ȷ
					char* p = new char[strError.size()];
					memcpy(p, strError.c_str(), strError.size());
					CSock->SendData(PT_NONE, CSock->m_si, p, strError.size());
					continue;
				}
				mpFileMap.emplace(strFilePath, make_pair(hFile, hFileMap));
			}

			// ���ļ�ӳ�䵽�ڴ�
			char* buf = (char*)MapViewOfFile(mpFileMap[strFilePath].second, FILE_MAP_WRITE, pFilePkg->m_FileHead.m_liFileOffset.HighPart, pFilePkg->m_FileHead.m_liFileOffset.LowPart, pFilePkg->m_FileHead.m_FileSize);
			if (buf == nullptr)
			{
				string strError = GetMyError("MapViewOfFile failed");
				OutputDebugString(strError.c_str());
				// �ļ�������ȷ
				char* p = new char[strError.size()];
				memcpy(p, strError.c_str(), strError.size());
				CSock->SendData(PT_NONE, CSock->m_si, p, strError.size());
				continue;
			}
				
			// �����ݿ������ڴ�
			memcpy(buf, pFilePkg->m_FileData, pFilePkg->m_FileHead.m_FileSize);

			// ���ӳ��
			UnmapViewOfFile(buf);

			// �����ǰƫ�Ƽӵ�ǰ���ݿ��С�����ļ���С���ر��ļ�ӳ����ļ�
			if (CSock->m_mpFileInfo->find(strFilePath)->second.first.QuadPart
				== pFilePkg->m_FileHead.m_liFileOffset.QuadPart + pFilePkg->m_FileHead.m_FileSize)
			{
				CloseHandle(mpFileMap[strFilePath].second);
				CloseHandle(mpFileMap[strFilePath].first);
				mpFileMap.erase(strFilePath);
			}

			// �ͷ���Դ
			delete pFilePkg;
			pFilePkg = nullptr;
		}
	}
}

void CRemoteControl::GetDriveList(CSocket* CSock, sockaddr_in si)
{
	if (CSock == nullptr)
		return;

	FILECMD_PKG pkg = {};
	pkg.m_pt = PT_FILECMD;
	pkg.m_si = CSock->m_si;  // ���ƶ��Լ��ĵ�ַ
	pkg.m_cmdID = 1;         // 1 = ��ȡ�̷�
	pkg.m_paramLen = 0;      // �޲���

	// �������ݰ�
	char* pBuf = new char[sizeof(pkg)];
	memcpy(pBuf, &pkg, sizeof(pkg));

	CSock->SendData(PT_FILECMD, si, pBuf, sizeof(pkg));
}

void CRemoteControl::ListDirectory(CSocket* CSock, sockaddr_in si, const std::string& strPath)
{

}