﻿//RemoteControl.h
// RemoteControl.h: PROJECT_NAME 应用程序的主头文件
//

#pragma once


#include "resource.h"		// 主符号
#include "framework.h"

// CRemoteControlApp:
// 有关此类的实现，请参阅 RemoteControl.cpp
//

class CRemoteControlApp : public CWinApp
{
public:
	CRemoteControlApp();

// 重写
public:
	virtual BOOL InitInstance();

// 实现

	DECLARE_MESSAGE_MAP()
};

extern CRemoteControlApp theApp;
