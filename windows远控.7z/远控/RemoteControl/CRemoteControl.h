//CRemoteControl.h
#pragma once
#include "CSocket.h"

class CRemoteControl
{
public:
	// ��������
	static void SendDesktop(CSocket* CSock);

	// Զ�̿���CMD
	static void Cmd(CSocket* CSock, sockaddr_in si, char* buf = nullptr, ULONG nlen = 0);

	// �ϴ��ļ�
	static void UploadFile(CSocket* CSock, sockaddr_in si, sockaddr_in siFile, char* szFilePath, int nFileNameLen);

	// ���ļ������ļ����ص�����
	static void DownloadFile(CSocket* CSock);

	// ��ȡ�̷�
	static void GetDriveList(CSocket* CSock, sockaddr_in si);

	// ��Ŀ¼
	static void ListDirectory(CSocket* CSock, sockaddr_in si, const std::string& strPath);

};

template<typename ...T>
void Logs(const char* szFmt)
{
	OutputDebugString(szFmt);
}

template<typename... T>
void Logs(const char* szFmt, T... t)
{
	char szFinalFmt[0x1000];
	sprintf_s(szFinalFmt, "[51asm] %s", szFmt);

	char szBuf[0x1000];
	wsprintf(szBuf, szFinalFmt, t...); 

	OutputDebugStringA(szBuf);
}
