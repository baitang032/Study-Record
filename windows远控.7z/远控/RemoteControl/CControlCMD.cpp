﻿// CControlCMD.cpp: 实现文件
//

#include "RemoteControl.h"
#include "afxdialogex.h"
#include "CControlCMD.h"
#include "RemoteControlDlg.h"
#include "CRemoteControl.h"


// CControlCMD 对话框

IMPLEMENT_DYNAMIC(CControlCMD, CDialog)

CControlCMD::CControlCMD(CWnd* pParent /*=nullptr*/)
	: CDialog(IDD_CControlCMD, pParent)
{

}

CControlCMD::~CControlCMD()
{
}

void CControlCMD::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, EDIT_RECVCMD, m_CEditDisplay);
}


BEGIN_MESSAGE_MAP(CControlCMD, CDialog)
	ON_BN_CLICKED(BTN_SEND, &CControlCMD::OnBnClickedSend)
	ON_WM_CLOSE()
END_MESSAGE_MAP()


// CControlCMD 消息处理程序


BOOL CControlCMD::DestroyWindow()
{

	return CDialog::DestroyWindow();
}


void CControlCMD::OnBnClickedSend()
{
	// 发送cmd命令
	CString strCmd;
	GetDlgItemText(EDIT_SENDCMD, strCmd);
	strCmd += "\r\n";
	SetDlgItemText(EDIT_SENDCMD, "");
	CRemoteControl::Cmd(&((CRemoteControlDlg*)(AfxGetApp()->m_pMainWnd))->m_CSock, m_si, strCmd.GetBuffer(), strCmd.GetLength());
}


BOOL CControlCMD::OnInitDialog()
{
	CDialog::OnInitDialog();

	// 发送cmd命令
	CRemoteControl::Cmd(&((CRemoteControlDlg*)(AfxGetApp()->m_pMainWnd))->m_CSock, m_si);

	return TRUE;  // return TRUE unless you set the focus to a control
	// 异常: OCX 属性页应返回 FALSE
}


void CControlCMD::OnClose()
{
	((CRemoteControlDlg*)(AfxGetApp()->m_pMainWnd))->DestoryDlg(m_si, PT_CMD);
}
