//CSocket.h
#pragma once
//#include <Windows.h>
#include <afxwin.h>
#include <Winsock2.h>
#include <map>
#include <queue>
#include <mutex>
#include <thread>
#include <string>
#include <afx.h>
#include <vector>
#define MAXDATA 0x40000000 // ������С
#define WM_REFRESH_DRIVE_LIST 10024
#pragma comment(lib, "Ws2_32.lib")

using namespace std;

#pragma pack(push)
#pragma pack(1)

// ������
enum PKG_TYPE
{
    PT_NONE,
    PT_SCREEN,        // ��Ļ
    PT_MOUSEMSG,      // ���
    PT_KEYBOARD,      // ����
    PT_CMD,           // �ܵ�
    PT_UPFILE,        // �ϴ��ļ�
    PT_DOWNFILE,      // �����ļ�
    PT_TRANSFERSTART, // ��ʼ����
    PT_TRANSFER,      // ���ڴ���
    PT_TRANSFEREND,   // ��������
    PT_QUERYFILE,     //�ļ��鿴
    PT_FILEINFO,      //�ļ���
    PT_FILECMD,       //�鿴����
};

// �����Ϣ
struct MOUSEMSG
{
    int   m_Msg;
    POINT m_point;
};

struct PACKAGE
{
    PACKAGE() {}
    PACKAGE(PKG_TYPE pt, sockaddr_in si, char* buf, ULONG size, bool IsSlitHead = false) {
        m_pt = pt;
        m_si = si;
        m_wsabuf.len = size;
        m_wsabuf.buf = new char[size] {};
        memcpy(m_wsabuf.buf, buf, size);
    }
    PACKAGE(ULONG size) {
        m_wsabuf.len = size;
        m_wsabuf.buf = new char[size] {};
    }
    PACKAGE(PKG_TYPE pt, sockaddr_in si) {
        m_pt = pt;
        m_si = si;
    }
    ~PACKAGE() {
        if (m_wsabuf.buf != nullptr)
        {
            delete[] m_wsabuf.buf;
            m_wsabuf.buf = nullptr;
        }
    }
    int size() const {
        return sizeof(m_pt) + sizeof(m_si) + sizeof(m_wsabuf) + m_wsabuf.len;
    }
    PKG_TYPE m_pt = {};
    sockaddr_in m_si = {};
    WSABUF   m_wsabuf = {};
};

struct FILEPKGHEAD
{
    PKG_TYPE m_pt = {};
    sockaddr_in m_si = {};
    LARGE_INTEGER m_liFileOffset = {};
    size_t    m_FileNameLen = {};
    size_t    m_FileSize = {};
};

struct FILEINFO
{
    FILEINFO(size_t nFileNameLen, LARGE_INTEGER liFileSize, char* szFileName) {
        m_nFileNameLen = nFileNameLen;
        m_liFileSize = liFileSize;
        m_szFileName = new char[nFileNameLen] {};
        memcpy(m_szFileName, szFileName, nFileNameLen);
    }
    FILEINFO(size_t nDataLen, char* data) {
        m_nFileNameLen = *(size_t*)data;
        m_liFileSize = *(LARGE_INTEGER*)(data + sizeof(m_nFileNameLen));
        m_szFileName = new char[m_nFileNameLen] {};
        memcpy(m_szFileName, data + sizeof(m_nFileNameLen) + sizeof(m_liFileSize), m_nFileNameLen);
    }
    size_t size() {
        return sizeof(m_nFileNameLen) + sizeof(m_liFileSize) + m_nFileNameLen;
    }
    ~FILEINFO() {
        if (m_szFileName != nullptr)
        {
            delete[] m_szFileName;
            m_szFileName = nullptr;
        }
    }
    size_t m_nFileNameLen = {};
    LARGE_INTEGER m_liFileSize = {};
    char* m_szFileName;
};

struct FILEPKG 
{
    FILEPKG(PKG_TYPE pt, sockaddr_in si, LARGE_INTEGER liFileOffset, char* szFileName, size_t nFileNameLen, char* data, size_t nDataSize) {
        m_FileHead.m_pt = pt;
        m_FileHead.m_si = si;
        m_FileHead.m_liFileOffset = liFileOffset;
        m_FileHead.m_FileNameLen = nFileNameLen;
        m_FileName = new char[nFileNameLen] {};
        memcpy(m_FileName, szFileName, nFileNameLen);
        m_FileHead.m_FileSize = nDataSize;
        m_FileData = new char[nDataSize] {};
        memcpy(m_FileData, data, nDataSize);
    }
    FILEPKG(FILEPKGHEAD fph):m_FileHead{fph}
    {
        m_FileName = new char[fph.m_FileNameLen] {};
        m_FileData = new char[fph.m_FileSize] {};
    }
    FILEPKG(size_t nFileNameLen, size_t nDataSize)
    {
        m_FileHead.m_FileNameLen = nFileNameLen;
        m_FileName = new char[nFileNameLen] {};
        m_FileHead.m_FileSize = nDataSize;
        m_FileData = new char[nDataSize] {};
    }
    ~FILEPKG() {
        if (m_FileName != nullptr)
        {
            delete[] m_FileName;
            m_FileName = nullptr;
        }
        if (m_FileData != nullptr)
        {
            delete[] m_FileData;
            m_FileData = nullptr;
        }
    }
    size_t size() {
        return sizeof(m_FileHead)  + m_FileHead.m_FileNameLen + m_FileHead.m_FileSize;
    }
    FILEPKGHEAD m_FileHead;
    char* m_FileName;
    char* m_FileData;
};
#pragma pack(pop)

#pragma pack(push, 1)
struct FILECMD_PKG
{
    PKG_TYPE m_pt = PT_FILECMD;   // �̶�Ϊ PT_FILECMD
    sockaddr_in m_si = {};        // ���ƶ˵�ַ
    int m_cmdID = 0;              // 1=��ȡ�̷���2=��Ŀ¼
    size_t m_paramLen = 0;        // ��������
    // char param[] �������
};
#pragma pack(pop)



struct sockaddr_in_compare {
    bool operator()(const sockaddr_in& lhs, const sockaddr_in& rhs) const {
        // �Ƚ� IP ��ַ�Ͷ˿ں�
        if (lhs.sin_addr.s_addr != rhs.sin_addr.s_addr) {
            return lhs.sin_addr.s_addr < rhs.sin_addr.s_addr;
        }
        return lhs.sin_port < rhs.sin_port;
    }
};

class CSocket
{
public:
    CSocket();
	CSocket(const char* IP, USHORT port, USHORT portFile, bool isServer = true);
    ~CSocket();
    // ����IP��ַ�Ͷ˿�
    void SetAddr(const char* IP, USHORT port, USHORT portFile, bool isServer = true);
    // ����
    void Connect(const char* IP, USHORT port, USHORT portFile);
    // ��������
    void SendData(PKG_TYPE pt, sockaddr_in si, char* data = nullptr, size_t nSize = 0);
    void SendFile(PKG_TYPE pt, sockaddr_in si, char* szFileName, int nFileNameLen, char* data, size_t nDataSize);

public:
    bool m_bStopThread = false;
    // �ͻ���
    recursive_mutex  m_mtClients;
    map<sockaddr_in, tuple<sockaddr_in, SOCKET, sockaddr_in, SOCKET>, sockaddr_in_compare>* m_mpClients = nullptr;
    // �ļ���Ϣ
    recursive_mutex  m_mtFileInfo;
    map<string, pair<LARGE_INTEGER, LARGE_INTEGER>>* m_mpFileInfo = nullptr;
    // ������
    recursive_mutex m_mtRecvData;
    queue<PACKAGE*>* m_quRecvData = nullptr;
    // �ļ���
    recursive_mutex m_mtRecvFile;
    queue<FILEPKG*>* m_quRecvFile = nullptr;
    // ��ǰ����IP��ַ�Ͷ˿ں�
    sockaddr_in m_si = {};
    sockaddr_in m_siFile = {};
    // Զ������IP��ַ�Ͷ˿ں�
    sockaddr_in m_siDistance = {};
    sockaddr_in m_siFileDistance = {};
private:
    // ���������߳�
    void acceptThread();

    // ������Ϣ�߳�
    void recvThread(sockaddr_in si);
    void recvFileThread(sockaddr_in siFile);

    // ������Ϣ�߳�
    void SendThread();
    void SendFileThread();

    // �հ�
    size_t RecvNumPkg(sockaddr_in si, char* szBuf, size_t nSize);
    PACKAGE* RecvPkg(sockaddr_in si);
    size_t RecvNumFile(sockaddr_in si, char* szBuf, size_t nSize);
    FILEPKG* RecvFile(sockaddr_in si);

    // �׽���
    SOCKET m_sock = INVALID_SOCKET;
    SOCKET m_sockFile = INVALID_SOCKET;

    // ������
    recursive_mutex m_mtSendData;
    queue<PACKAGE*>* m_quSendData = nullptr;

    // �ļ���
    //recursive_mutex m_mtSendFile;
    std::mutex m_mtSendFile;                     // ���Ͷ��л�����
    queue<FILEPKG*>* m_quSendFile = nullptr;

    // ������
    bool m_bIsServer = false;
};

class _WSAStartUP {
public:
    _WSAStartUP() {
        WORD wVersionRequested;
        WSADATA wsaData;
        int err;

        wVersionRequested = MAKEWORD(2, 2);

        err = WSAStartup(wVersionRequested, &wsaData);
        if (err != 0) {
            /* Tell the user that we could not find a usable */
            /* WinSock DLL.                                  */
            return;
        }

        /* Confirm that the WinSock DLL supports 2.2.*/
        /* Note that if the DLL supports versions greater    */
        /* than 2.2 in addition to 2.2, it will still return */
        /* 2.2 in wVersion since that is the version we      */
        /* requested.                                        */

        if (LOBYTE(wsaData.wVersion) != 2 ||
            HIBYTE(wsaData.wVersion) != 2) {
            /* Tell the user that we could not find a usable */
            /* WinSock DLL.                                  */
            WSACleanup();
            return;
        }

        /* The WinSock DLL is acceptable. Proceed. */
	}
};
static _WSAStartUP __init;

static string GetMyError(const char* buf) {
    LPVOID lpMsgBuf;
    FormatMessage(
        FORMAT_MESSAGE_ALLOCATE_BUFFER |
        FORMAT_MESSAGE_FROM_SYSTEM |
        FORMAT_MESSAGE_IGNORE_INSERTS,
        NULL,
        GetLastError(),
        MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
        (LPTSTR)&lpMsgBuf,
        0,
        NULL
    );
    string str;
    str += buf;
    str += " Error [51asm] ";
    str += to_string(GetLastError());
    str += ": ";
    str += (char*)lpMsgBuf;
    LocalFree(lpMsgBuf);
    return str;
}


