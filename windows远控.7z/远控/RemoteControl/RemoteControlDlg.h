﻿
// RemoteControlDlg.h: 头文件
//

#pragma once
#include "CSocket.h"
#include "CdlgDesktop.h"
#include "CControlCMD.h"
#include "CdlgFileTransfer.h"
#include "CdlgFileView.h"

// CRemoteControlDlg 对话框
class CRemoteControlDlg : public CDialogEx
{
// 构造
public:
	CRemoteControlDlg(CWnd* pParent = nullptr);	// 标准构造函数

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_REMOTECONTROL_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV 支持


// 实现
protected:
	HICON m_hIcon;

	// 生成的消息映射函数
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	// CMD回显
	CString m_strEchoCMD;
	CSocket   m_CSock;
	CListCtrl m_ListHost;
	map<sockaddr_in, tuple<CdlgDesktop*, CControlCMD*, CdlgFileTransfer*, CdlgFileView*>, sockaddr_in_compare> m_mpDlg;
	mutex m_mtDlg;
	int m_nSelectHostIdx;
	bool m_bStopThread = false;
	// 销毁对话框
	void DestoryDlg(sockaddr_in si, PKG_TYPE pt);
	void HandleThread();
	// 初始化主机列表
	void InitListCtrl();
	// 更新主机列表
	void UpDataListCtrl();
	void ShowRemoteDesktop(CdlgDesktop* pdlg, WSABUF wsaBuf);
	virtual BOOL DestroyWindow();
	afx_msg void OnDblclkListHost(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnRclickListHost(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnClickListHost(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnRbtnScreen();
	afx_msg void OnRbtnCmd();
	afx_msg void OnRbtnFiletransfer();
	afx_msg void OnRbtnFileView();
	CdlgFileView* GetFileViewDialog();
};
