﻿
// RemoteControlDlg.cpp: 实现文件
//

#include "framework.h"
#include "RemoteControl.h"
#include "RemoteControlDlg.h"
#include "afxdialogex.h"
#include "CdlgFileView.h"
#include "CRemoteControl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// 用于应用程序“关于”菜单项的 CAboutDlg 对话框

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

// 实现
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CRemoteControlDlg 对话框



CRemoteControlDlg::CRemoteControlDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_REMOTECONTROL_DIALOG, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CRemoteControlDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, LIST_HOST, m_ListHost);
}

BEGIN_MESSAGE_MAP(CRemoteControlDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_TIMER()
	ON_NOTIFY(NM_DBLCLK, LIST_HOST, &CRemoteControlDlg::OnDblclkListHost)
	ON_NOTIFY(NM_RCLICK, LIST_HOST, &CRemoteControlDlg::OnRclickListHost)
	ON_NOTIFY(NM_CLICK, LIST_HOST, &CRemoteControlDlg::OnClickListHost)
	ON_COMMAND(RBTN_SCREEN, &CRemoteControlDlg::OnRbtnScreen)
	ON_COMMAND(RBTN_CMD, &CRemoteControlDlg::OnRbtnCmd)
	ON_COMMAND(RBTN_FILETRANSFER, &CRemoteControlDlg::OnRbtnFiletransfer)
	ON_COMMAND(RBTN_FILEVIEW, &CRemoteControlDlg::OnRbtnFileView)
END_MESSAGE_MAP()


// CRemoteControlDlg 消息处理程序

BOOL CRemoteControlDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// 将“关于...”菜单项添加到系统菜单中。

	// IDM_ABOUTBOX 必须在系统命令范围内。
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// 设置此对话框的图标。  当应用程序主窗口不是对话框时，框架将自动
	//  执行此操作
	SetIcon(m_hIcon, TRUE);			// 设置大图标
	SetIcon(m_hIcon, FALSE);		// 设置小图标

	// TODO: 在此添加额外的初始化代码
	m_CSock.SetAddr("192.168.1.2", 0x9530, 0x9531);
	InitListCtrl();

	return TRUE;  // 除非将焦点设置到控件，否则返回 TRUE
}

void CRemoteControlDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// 如果向对话框添加最小化按钮，则需要下面的代码
//  来绘制该图标。  对于使用文档/视图模型的 MFC 应用程序，
//  这将由框架自动完成。

void CRemoteControlDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // 用于绘制的设备上下文

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// 使图标在工作区矩形中居中
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// 绘制图标
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

//当用户拖动最小化窗口时系统调用此函数取得光标
//显示。
HCURSOR CRemoteControlDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


CString SanitizeCString(const char* src)
{
	CString result;
	while (*src)
	{
		// 过滤掉控制字符（0x00 ~ 0x1F 和 0x7F）
		if ((unsigned char)*src >= 32 && (unsigned char)*src != 127)
			result += *src;
		++src;
	}
	return result;
}


void CRemoteControlDlg::OnTimer(UINT_PTR nIDEvent)
{
	CDialogEx::OnTimer(nIDEvent);
}

void CRemoteControlDlg::DestoryDlg(sockaddr_in si, PKG_TYPE pt)
{
	switch (pt)
	{
	case PT_SCREEN:
	{
		m_mtDlg.lock();
		CdlgDesktop* pdlg = std::get<0>(m_mpDlg[si]);
		std::get<0>(m_mpDlg[si]) = nullptr;
		m_mtDlg.unlock();
		if (pdlg != nullptr)
		{
			pdlg->DestroyWindow();
			delete pdlg;
			pdlg = nullptr;
		}
		break;
	}
	case PT_CMD:
	{
		m_mtDlg.lock();
		CControlCMD* pdlg = std::get<1>(m_mpDlg[si]);
		std::get<1>(m_mpDlg[si]) = nullptr;
		m_mtDlg.unlock();
		if (pdlg != nullptr)
		{
			pdlg->DestroyWindow();
			delete pdlg;
			pdlg = nullptr;
		}
		break;
	}
	case PT_TRANSFEREND:
	{
		m_mtDlg.lock();
		CdlgFileTransfer* pdlg = std::get<2>(m_mpDlg[si]);
		std::get<2>(m_mpDlg[si]) = nullptr;
		m_mtDlg.unlock();
		if (pdlg != nullptr)
		{
			pdlg->DestroyWindow();
			delete pdlg;
			pdlg = nullptr;
		}
		break;
	}
	}
}

void CRemoteControlDlg::HandleThread()
{
	while (!m_bStopThread)
	{
		// 接收队列取包
		if (!m_CSock.m_quRecvData->empty())
		{
			PACKAGE* pkg = nullptr;

			m_CSock.m_mtRecvData.lock();
			pkg = m_CSock.m_quRecvData->front();
			m_CSock.m_quRecvData->pop();
			m_CSock.m_mtRecvData.unlock();
			// 分析包
			switch (pkg->m_pt)
			{
			case PT_SCREEN:
			{
				// 显示屏幕
				m_mtDlg.lock();
				CdlgDesktop* pdlg = std::get<0>(m_mpDlg[pkg->m_si]);
				m_mtDlg.unlock();
				if (pdlg != nullptr)
				{
					ShowRemoteDesktop(pdlg, pkg->m_wsabuf);
				}
				break;
			}
			case PT_CMD:
			{
				// 获取CMD
				m_mtDlg.lock();
				CControlCMD* pdlg = std::get<1>(m_mpDlg[pkg->m_si]);
				m_mtDlg.unlock();
				if (pdlg != nullptr)
				{
					m_strEchoCMD += CString(pkg->m_wsabuf.buf, pkg->m_wsabuf.len);
					pdlg->SetDlgItemText(EDIT_RECVCMD, m_strEchoCMD);
					pdlg->m_CEditDisplay.LineScroll(pdlg->m_CEditDisplay.GetLineCount());
				}
				break;
			}
			case PT_UPFILE:
			{
				// 接收到客户端请求文件
				char* pFilePath = new char[pkg->m_wsabuf.len];
				memcpy(pFilePath, pkg->m_wsabuf.buf, pkg->m_wsabuf.len);
				CRemoteControl::UploadFile(&m_CSock, pkg->m_si, get<2>(m_CSock.m_mpClients->find(pkg->m_si)->second), pFilePath, pkg->m_wsabuf.len);
				break;
			}
			case PT_TRANSFERSTART:
			{
				// 传输开始、得到文件名文件大小
				FILEINFO fi(pkg->m_wsabuf.len, pkg->m_wsabuf.buf);
				string strFileName(fi.m_szFileName, fi.m_nFileNameLen);
				// 将文件信息放入文件MAP
				m_CSock.m_mtFileInfo.lock();
				get<0>((*m_CSock.m_mpFileInfo)[strFileName]) = fi.m_liFileSize;
				get<1>((*m_CSock.m_mpFileInfo)[strFileName]) = { 0 };
				m_CSock.m_mtFileInfo.unlock();
				m_mtDlg.lock();
				CdlgFileTransfer* pdlg = std::get<2>(m_mpDlg[pkg->m_si]);
				m_mtDlg.unlock();
				if (pdlg != nullptr)
				{
					// 更新列表
					pdlg->UpdateListFile();
				}
				break;
			}
			case PT_TRANSFER:
			{
				// 得到文件进度
				FILEINFO fi(pkg->m_wsabuf.len, pkg->m_wsabuf.buf);
				string strFileName(fi.m_szFileName, fi.m_nFileNameLen);
				// 将文件信息放入文件MAP
				m_CSock.m_mtFileInfo.lock();
				get<1>((*m_CSock.m_mpFileInfo)[strFileName]) = fi.m_liFileSize;
				m_CSock.m_mtFileInfo.unlock();
				m_mtDlg.lock();
				CdlgFileTransfer* pdlg = std::get<2>(m_mpDlg[pkg->m_si]);
				m_mtDlg.unlock();
				if (pdlg != nullptr)
				{
					// 更新列表
					pdlg->UpdateListFile();
				}
				break;
			}
			case PT_TRANSFEREND:
			{
				// 文件传出结束
				FILEINFO fi(pkg->m_wsabuf.len, pkg->m_wsabuf.buf);
				string strFileName(fi.m_szFileName, fi.m_nFileNameLen);
				// 将文件信息放入文件MAP
				m_CSock.m_mtFileInfo.lock();
				get<1>((*m_CSock.m_mpFileInfo)[strFileName]) = fi.m_liFileSize;
				m_CSock.m_mtFileInfo.unlock();
				m_mtDlg.lock();
				CdlgFileTransfer* pdlg = std::get<2>(m_mpDlg[pkg->m_si]);
				m_mtDlg.unlock();
				if (pdlg != nullptr)
				{
					// 更新列表
					pdlg->UpdateListFile();
				}
				break;
			}
			case PT_FILECMD:
			{

				if (pkg->m_wsabuf.len < sizeof(FILECMD_PKG))
					break;
				Sleep(1);
				FILECMD_PKG* pCmd = (FILECMD_PKG*)pkg->m_wsabuf.buf;

				if (pCmd->m_cmdID == 1) // 处理获取盘符的回复
				{
					char* pDriveData = (char*)(pCmd + 1);
					size_t driveDataLen = pkg->m_wsabuf.len - sizeof(FILECMD_PKG);

					// 先拿到 CdlgFileView 指针（假设你保存在 m_mpDlg 映射表中）
					CdlgFileView* pFileViewDlg = nullptr;
					{
						std::lock_guard<std::mutex> lock(m_mtDlg);
						auto it = m_mpDlg.find(pkg->m_si);
						if (it != m_mpDlg.end())
							pFileViewDlg = std::get<3>(it->second);  // 第四项是文件窗口
					}

					if (pFileViewDlg)
					{
						DriveListData* pDriveList = new DriveListData();

						char* p = pDriveData;
						while (p < pDriveData + driveDataLen && *p)
						{
							pDriveList->drives.emplace_back(p);
							p += strlen(p) + 1;
						}

						// 发消息到 CdlgFileView 让它更新 UI
						pFileViewDlg->PostMessage(WM_REFRESH_DRIVE_LIST, (WPARAM)pDriveList, 0);
					}
				}

				else if (pCmd->m_cmdID == 2)
				{
					char* p = (char*)(pCmd + 1);
					char* end = pkg->m_wsabuf.buf + pkg->m_wsabuf.len;
					m_mtDlg.lock();
					// 获取子窗口指针
					CdlgFileView* pFileViewDlg = std::get<3>(m_mpDlg[pkg->m_si]);
					m_mtDlg.unlock();

					if (pFileViewDlg != nullptr)
					{
						pFileViewDlg->m_listwnd.DeleteAllItems();

						int idx = 0;
						while (p < end && *p)
						{
							if (end - p < 2) break; // 至少要两个字符串

							CString name(p);
							p += strlen(p) + 1;

							if (p >= end) break;

							CString path(p);
							p += strlen(p) + 1;

							pFileViewDlg->m_listwnd.InsertItem(idx, name);
							pFileViewDlg->m_listwnd.SetItemText(idx, 1, path);
							++idx;
						}
					}
					pFileViewDlg->m_listwnd.SetColumnWidth(0, LVSCW_AUTOSIZE_USEHEADER);
					pFileViewDlg->m_listwnd.SetColumnWidth(1, LVSCW_AUTOSIZE_USEHEADER);
				}

				break;
			}


			}
			if (pkg != nullptr)
			{
				delete pkg;
				pkg = nullptr;
			}

		}
	}
}

void CRemoteControlDlg::InitListCtrl()
{
	// 初始化主机列表
	m_ListHost.InsertColumn(0, "序号");
	m_ListHost.InsertColumn(1, "地址");
	m_ListHost.InsertColumn(2, "端口");

	// 设置列宽
	CRect rc;
	m_ListHost.GetWindowRect(&rc);
	int width = rc.Width() / 5;
	m_ListHost.SetColumnWidth(0, width);
	m_ListHost.SetColumnWidth(1, width * 3);
	m_ListHost.SetColumnWidth(2, width);
	
	// 设置样式
	m_ListHost.SetExtendedStyle(LVS_EX_GRIDLINES | LVS_EX_FULLROWSELECT);

	// 处理包线程
	thread t(&CRemoteControlDlg::HandleThread, this);
	t.detach();

	// 开启接收文件线程
	thread t1([&]() {
		CRemoteControl::DownloadFile(&m_CSock);
		});
	t1.detach();
}

void CRemoteControlDlg::UpDataListCtrl()
{
	// 清空列表
	m_ListHost.DeleteAllItems();

	// 将主机填入列表
	std::lock_guard<std::recursive_mutex> lock(m_CSock.m_mtClients);
	int i = 0;
	for (auto& pc : *m_CSock.m_mpClients)
	{
		CString fmt;
		fmt.Format("%d", i);
		m_ListHost.InsertItem(i, fmt);
		fmt.Format("%s", inet_ntoa(pc.first.sin_addr));
		m_ListHost.SetItemText(i, 1, fmt);
		fmt.Format("%x, %x", htons(pc.first.sin_port), htons(get<2>(pc.second).sin_port));
		m_ListHost.SetItemText(i, 2, fmt);
		m_ListHost.SetItemData(i, (DWORD_PTR)&pc.first);
		i++;
	}
}

void CRemoteControlDlg::ShowRemoteDesktop(CdlgDesktop* pdlg, WSABUF wsaBuf)
{

	char* p = wsaBuf.buf;

	// 获取宽高
	int width = *(int*)p; p += sizeof(int);
	int height = *(int*)p; p += sizeof(int);

	pdlg->m_RemoteScreenWidth = width;
	pdlg->m_RemoteScreenHeight = height;

	// 将桌面位图复制到对话框位图

	CDC desktop;
	desktop.Attach(::GetDC(NULL));

	// 创建内存位图
	CBitmap bmp;
	bmp.CreateCompatibleBitmap(&desktop, width, height);
	bmp.SetBitmapBits(wsaBuf.len - sizeof(int) * 2, p);
	// 获取位图信息
	BITMAP bmpInfo;
	bmp.GetBitmap(&bmpInfo);

	// 创建内存DC
	CDC dcMemory;
	dcMemory.CreateCompatibleDC(pdlg->GetDC());

	// 选择位图到内存DC
	CBitmap* pOldBitmap = dcMemory.SelectObject(&bmp);

	// 显示到对话框
	CRect rc;
	pdlg->GetClientRect(rc);
	if (!(pdlg->GetDC())->StretchBlt(
		0, 0, rc.Width(), rc.Height(), 
		&dcMemory,
		0, 0, width, height, SRCCOPY))
	{
		OutputDebugString(GetMyError("bitblt").c_str());
	}
}


void CRemoteControlDlg::OnDblclkListHost(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	*pResult = 0;
	m_nSelectHostIdx = pNMItemActivate->iItem;
}


BOOL CRemoteControlDlg::DestroyWindow()
{
	// TODO: 在此添加专用代码和/或调用基类
	m_CSock.m_bStopThread = true;
	m_bStopThread = true;
	return CDialogEx::DestroyWindow();
}


void CRemoteControlDlg::OnRclickListHost(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	*pResult = 0;
	// 右键菜单
	m_nSelectHostIdx = pNMItemActivate->iItem;
	CPoint pt;
	GetCursorPos(&pt);
	ScreenToClient(&pt);
	if (m_nSelectHostIdx != -1)
	{
		CMenu menu;
		menu.LoadMenu(MENU_RBTN);
		CMenu* pPopup = menu.GetSubMenu(0);
		ClientToScreen(&pt);
		pPopup->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON, pt.x, pt.y, this);
	}
}


void CRemoteControlDlg::OnClickListHost(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: 在此添加控件通知处理程序代码
	*pResult = 0;
	m_nSelectHostIdx = pNMItemActivate->iItem;
}


void CRemoteControlDlg::OnRbtnScreen()
{
	// 创建非模态对话框
	CdlgDesktop* pDlg = new CdlgDesktop(this);
	pDlg->m_si = *(sockaddr_in*)m_ListHost.GetItemData(m_nSelectHostIdx);
	pDlg->Create(IDD_CDLGDESKTOP, this);
	pDlg->ShowWindow(SW_SHOW);
	m_mtDlg.lock();
	get<0>(m_mpDlg[pDlg->m_si]) = pDlg;
	m_mtDlg.unlock();
}


void CRemoteControlDlg::OnRbtnCmd()
{
	// 创建非模态对话框
	CControlCMD* pDlg = new CControlCMD(this);
	pDlg->m_si = *(sockaddr_in*)m_ListHost.GetItemData(m_nSelectHostIdx);
	pDlg->Create(IDD_CControlCMD, this);
	pDlg->ShowWindow(SW_SHOW);
	m_mtDlg.lock();
	pDlg->SetDlgItemText(EDIT_RECVCMD, m_strEchoCMD);
	pDlg->m_CEditDisplay.LineScroll(pDlg->m_CEditDisplay.GetLineCount());
	get<1>(m_mpDlg[pDlg->m_si]) = pDlg;
	m_mtDlg.unlock();
}


void CRemoteControlDlg::OnRbtnFiletransfer()
{
	// 创建非模态对话框
	CdlgFileTransfer* pDlg = new CdlgFileTransfer(this);
	pDlg->m_si = *(sockaddr_in*)m_ListHost.GetItemData(m_nSelectHostIdx);
	pDlg->Create(DLG_FILETRANSFER, this);
	pDlg->ShowWindow(SW_SHOW);
	// 更新列表
	pDlg->UpdateListFile();
	m_mtDlg.lock();
	get<2>(m_mpDlg[pDlg->m_si]) = pDlg;
	m_mtDlg.unlock();
}


void CRemoteControlDlg::OnRbtnFileView()
{
	// 创建非模态对话框
	CdlgFileView* pDlg = new CdlgFileView(this);

	// 设置远程主机地址
	pDlg->m_si = *(sockaddr_in*)m_ListHost.GetItemData(m_nSelectHostIdx);

	// 设置发送用的 socket
	pDlg->m_pCSock = &m_CSock;

	pDlg->Create(IDD_DIALOG1, this);
	pDlg->ShowWindow(SW_SHOW);

	// 存储到 map
	m_mtDlg.lock();
	get<3>(m_mpDlg[pDlg->m_si]) = pDlg;
	m_mtDlg.unlock();
}

