﻿//CdlgFileView.h
#pragma once
#include "afxdialogex.h"
#include "CSocket.h"


// CdlgFileView 对话框

// 用于传递盘符列表数据的结构体
struct DriveListData
{
	std::vector<CString> drives;
};

class CdlgFileView : public CDialogEx
{
	DECLARE_DYNAMIC(CdlgFileView)

public:
	CdlgFileView(CWnd* pParent = nullptr);   // 标准构造函数
	virtual ~CdlgFileView();


// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG1 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持
	afx_msg LRESULT OnRefreshDriveList(WPARAM wParam, LPARAM lParam);

	DECLARE_MESSAGE_MAP()
public:


	afx_msg void OnBnClickedOk();
	CListCtrl m_listwnd;
	CString m_strCurrentPath; // 存储当前目录的路
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedBack();
	void Show_Disk();
	// 发送获取盘符请求
	void SendDriveListRequest();
	CString GetParentDirectory(const CString& strPath);
	void OnDblclkListShowwindow(NMHDR* pNMHDR, LRESULT* pResult);
	void OnClickListShowwindow(NMHDR* pNMHDR, LRESULT* pResult);
	void SendQueryRequest(const CString& strPath);
	CEdit m_findshuaxin;
	CString m_findtext;

	sockaddr_in m_si;
	CSocket* m_pCSock;
};
