﻿// CdlgDesktop.cpp: 实现文件
//

#include "framework.h"
#include "RemoteControl.h"
#include "afxdialogex.h"
#include "CdlgDesktop.h"
#include "RemoteControlDlg.h"


// CdlgDesktop 对话框

IMPLEMENT_DYNAMIC(CdlgDesktop, CDialog)

CdlgDesktop::CdlgDesktop(CWnd* pParent /*=nullptr*/)
	: CDialog(IDD_CDLGDESKTOP, pParent)
{

}

CdlgDesktop::~CdlgDesktop()
{
}

void CdlgDesktop::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CdlgDesktop, CDialog)
	ON_WM_TIMER()
	ON_WM_LBUTTONDOWN()
	ON_WM_RBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_RBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_MOUSEWHEEL()
	ON_WM_CLOSE()
	ON_WM_LBUTTONDBLCLK()
END_MESSAGE_MAP()


// CdlgDesktop 消息处理程序

void CdlgDesktop::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: 在此添加消息处理程序代码和/或调用默认值
	if (nIDEvent == 1)
	{
		((CRemoteControlDlg*)AfxGetMainWnd())->m_CSock.SendData(PT_SCREEN, m_si);
	}

	CDialog::OnTimer(nIDEvent);
}


BOOL CdlgDesktop::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  在此添加额外的初始化
	SetTimer(1, 100, nullptr);
	GetClientRect(m_rc);

	// 设置对话框扩展风格
	DWORD dwStyle = GetWindowLong(m_hWnd, GWL_STYLE);
	dwStyle |= WS_EX_COMPOSITED;
	SetWindowLong(m_hWnd, GWL_STYLE, dwStyle);

	return TRUE;  // return TRUE unless you set the focus to a control
	// 异常: OCX 属性页应返回 FALSE
}


BOOL CdlgDesktop::DestroyWindow()
{
	// TODO: 在此添加专用代码和/或调用基类

	return CDialog::DestroyWindow();
}


void CdlgDesktop::OnLButtonDown(UINT nFlags, CPoint point)
{
	// 发送消息
	MOUSEMSG mMsg{};
	mMsg.m_Msg = WM_LBUTTONDOWN;
	mMsg.m_point.x = point.x * m_RemoteScreenWidth / m_rc.Width();
	mMsg.m_point.y = point.y * m_RemoteScreenHeight / m_rc.Height();
	char* pBuffer = new char[sizeof(mMsg)] {};
	memcpy(pBuffer, &mMsg, sizeof(mMsg));
	((CRemoteControlDlg*)AfxGetMainWnd())->m_CSock.SendData(PT_MOUSEMSG, m_si, pBuffer, sizeof(mMsg));

	CDialog::OnLButtonDown(nFlags, point);
}

void CdlgDesktop::OnRButtonDown(UINT nFlags, CPoint point)
{
	// 发送消息
	MOUSEMSG mMsg{};
	mMsg.m_Msg = WM_RBUTTONDOWN;
	mMsg.m_point.x = point.x * m_RemoteScreenWidth / m_rc.Width();
	mMsg.m_point.y = point.y * m_RemoteScreenHeight / m_rc.Height();
	char* pBuffer = new char[sizeof(mMsg)] {};
	memcpy(pBuffer, &mMsg, sizeof(mMsg));
	((CRemoteControlDlg*)AfxGetMainWnd())->m_CSock.SendData(PT_MOUSEMSG, m_si, pBuffer, sizeof(mMsg));

	CDialog::OnRButtonDown(nFlags, point);
}


void CdlgDesktop::OnLButtonUp(UINT nFlags, CPoint point)
{
	// 发送消息
	MOUSEMSG mMsg{};
	mMsg.m_Msg = WM_LBUTTONUP;
	mMsg.m_point.x = point.x * m_RemoteScreenWidth / m_rc.Width();
	mMsg.m_point.y = point.y * m_RemoteScreenHeight / m_rc.Height();
	char* pBuffer = new char[sizeof(mMsg)] {};
	memcpy(pBuffer, &mMsg, sizeof(mMsg));
	((CRemoteControlDlg*)AfxGetMainWnd())->m_CSock.SendData(PT_MOUSEMSG, m_si, pBuffer, sizeof(mMsg));

	CDialog::OnLButtonUp(nFlags, point);
}


void CdlgDesktop::OnRButtonUp(UINT nFlags, CPoint point)
{
	// 发送消息
	MOUSEMSG mMsg{};
	mMsg.m_Msg = WM_RBUTTONUP;
	mMsg.m_point.x = point.x * m_RemoteScreenWidth / m_rc.Width();
	mMsg.m_point.y = point.y * m_RemoteScreenHeight / m_rc.Height();
	char* pBuffer = new char[sizeof(mMsg)] {};
	memcpy(pBuffer, &mMsg, sizeof(mMsg));
	((CRemoteControlDlg*)AfxGetMainWnd())->m_CSock.SendData(PT_MOUSEMSG, m_si, pBuffer, sizeof(mMsg));

	CDialog::OnRButtonUp(nFlags, point);
}


void CdlgDesktop::OnMouseMove(UINT nFlags, CPoint point)
{
	// 左键按下才移动
	if (nFlags & WM_LBUTTONDOWN)
	{
		MOUSEMSG mMsg{};
		mMsg.m_Msg = WM_MOUSEMOVE;
		mMsg.m_point.x = point.x * m_RemoteScreenWidth / m_rc.Width();
		mMsg.m_point.y = point.y * m_RemoteScreenHeight / m_rc.Height();
		char* pBuffer = new char[sizeof(mMsg)] {};
		memcpy(pBuffer, &mMsg, sizeof(mMsg));
		((CRemoteControlDlg*)AfxGetMainWnd())->m_CSock.SendData(PT_MOUSEMSG, m_si, pBuffer, sizeof(mMsg));
	}

	CDialog::OnMouseMove(nFlags, point);
}


BOOL CdlgDesktop::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt)
{
	MOUSEMSG mMsg{};
	mMsg.m_Msg = WM_MOUSEWHEEL;
	mMsg.m_point.x = pt.x * m_RemoteScreenWidth / m_rc.Width();
	mMsg.m_point.y = pt.y * m_RemoteScreenHeight / m_rc.Height();
	char* pBuffer = new char[sizeof(mMsg) + sizeof(zDelta)] {};
	memcpy(pBuffer, &mMsg, sizeof(mMsg) + sizeof(zDelta));
	memcpy(pBuffer + sizeof(mMsg), &zDelta, sizeof(zDelta));
	((CRemoteControlDlg*)AfxGetMainWnd())->m_CSock.SendData(PT_MOUSEMSG, m_si, pBuffer, sizeof(mMsg) + sizeof(zDelta));

	return CDialog::OnMouseWheel(nFlags, zDelta, pt);
}


BOOL CdlgDesktop::PreTranslateMessage(MSG* pMsg)
{
	switch (pMsg->message)
	{
	case WM_KEYDOWN:
	case WM_KEYUP:
	case WM_SYSKEYDOWN:
	case WM_SYSKEYUP:
	{
		MSG msg{};
		msg = *pMsg;
		char* pBuffer = new char[sizeof(msg)] {};
		memcpy(pBuffer, &msg, sizeof(msg));
		((CRemoteControlDlg*)AfxGetMainWnd())->m_CSock.SendData(PT_KEYBOARD, m_si, pBuffer, sizeof(msg));
		return 0;
	}
	}

	return CDialog::PreTranslateMessage(pMsg);
}


void CdlgDesktop::OnClose()
{
	KillTimer(1);
	((CRemoteControlDlg*)(AfxGetApp()->m_pMainWnd))->DestoryDlg(m_si, PT_SCREEN);

}


void CdlgDesktop::OnLButtonDblClk(UINT nFlags, CPoint point)
{
	// 发送消息
	MOUSEMSG mMsg{};
	mMsg.m_Msg = WM_LBUTTONDBLCLK;
	mMsg.m_point.x = point.x * m_RemoteScreenWidth / m_rc.Width();
	mMsg.m_point.y = point.y * m_RemoteScreenHeight / m_rc.Height();
	char* pBuffer = new char[sizeof(mMsg)] {};
	memcpy(pBuffer, &mMsg, sizeof(mMsg));
	((CRemoteControlDlg*)AfxGetMainWnd())->m_CSock.SendData(PT_MOUSEMSG, m_si, pBuffer, sizeof(mMsg));

	CDialog::OnLButtonDblClk(nFlags, point);
}
