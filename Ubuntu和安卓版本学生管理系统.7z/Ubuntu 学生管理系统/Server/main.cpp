#include <iostream>
#include "main.h"
// TIP 要<b>Run</b>代码，请按 <shortcut actionId="Run"/> 或点击装订区域中的 <icon src="AllIcons.Actions.Execute"/> 图标。
#include "StudentDatabase.h"
#include "Package.h"
#include "CThreadPool.hpp"
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>
#include <cstring>
#include <thread>
#include <vector>
#include <sstream>
#include <algorithm>
#include <iostream>

// 全局对象
CThreadPool g_pool;    // 线程池对象
DataBase g_dataBase;   // 数据库操作类

// ----------------- 辅助函数 -----------------

const char* GetTableName(int tableType) {
    switch (tableType) {
        case TABLE_STUDENT:       return "student";
        case TABLE_CLASS:         return "class";
        case TABLE_COURSE:        return "course";
        case TABLE_ENROLL:        return "enroll";
        case TABLE_STUDENT_CLASS: return "student_class_map";
        case TABLE_VIEW_FULLINFO: return "student_full_info";
        default:                  return "unknown_table";
    }
}

bool NeedQuotes(int tableType, const std::string& fieldName) {
    switch (tableType) {
        case TABLE_STUDENT:
        case TABLE_CLASS:
        case TABLE_COURSE:
            return (fieldName != "id");
        case TABLE_STUDENT_CLASS:
            return false;
        case TABLE_ENROLL:
            return (fieldName != "id" && fieldName != "student_id" && fieldName != "course_id" && fieldName != "score");
        case TABLE_VIEW_FULLINFO:
            return !(fieldName == "student_id" || fieldName == "score");
        default:
            return true;
    }
}

// 拆分字符串
std::vector<std::string> SplitString(const char* str) {
    std::vector<std::string> result;
    if (!str || strlen(str) == 0) return result;

    std::string s(str);
    std::stringstream ss(s);
    std::string item;

    while (std::getline(ss, item, ',')) {
        item.erase(item.begin(), std::find_if(item.begin(), item.end(), [](unsigned char ch){ return !std::isspace(ch); }));
        item.erase(std::find_if(item.rbegin(), item.rend(), [](unsigned char ch){ return !std::isspace(ch); }).base(), item.end());
        if (!item.empty()) result.push_back(item);
    }
    return result;
}

// SQL 值处理
std::string SqlValue(const std::string& val, bool isNumber) {
    if (isNumber) return val;
    std::string escaped = val;
    size_t pos = 0;
    while ((pos = escaped.find('\'', pos)) != std::string::npos) {
        escaped.insert(pos, "'");
        pos += 2;
    }
    return "'" + escaped + "'";
}

// 格式化 SQL
std::string FormatSqlValue(int tableType, const std::string& field, const std::string& val) {
    return SqlValue(val, !NeedQuotes(tableType, field));
}
std::string FormatSqlLikeValue(int tableType, const std::string& field, const std::string& value) {
    return "'%" + value + "%'";
}

// ----------------- 数据库操作函数 -----------------

void InsertToTable(DataBase& db, int tableType, const char* fields, const char* values) {
    auto fieldList = SplitString(fields);
    auto valueList = SplitString(values);
    if (fieldList.size() != valueList.size()) {
        printf("错误：字段和值数量不匹配（字段:%zd 值:%zd）\n", fieldList.size(), valueList.size());
        return;
    }

    std::string sql = "INSERT INTO ";
    sql += GetTableName(tableType);
    sql += " (";

    std::string sqlValues = " VALUES (";
    for (size_t i = 0; i < fieldList.size(); i++) {
        if (i > 0) { sql += ", "; sqlValues += ", "; }
        sql += fieldList[i];
        bool isNumber = !NeedQuotes(tableType, fieldList[i]);
        sqlValues += SqlValue(valueList[i], isNumber);
    }
    sql += ")";
    sqlValues += ")";
    sql += sqlValues;

    printf("[SQL] %s\n", sql.c_str());
    db.AddDataBaseInfo(sql.c_str());
}

void DeleteFromTable(DataBase& db, int tableType, const char* whereClause) {
    std::string sql = "DELETE FROM ";
    sql += GetTableName(tableType);
    if (whereClause && strlen(whereClause) > 0) {
        sql += " WHERE ";
        sql += whereClause;
    }
    printf("[SQL] %s\n", sql.c_str());
    db.DeleteDataBaseInfo(sql.c_str());
}

void UpdateTable(DataBase& db, int tableType, const char* whereClause, const char* fields, const char* values) {
    auto fieldList = SplitString(fields);
    auto valueList = SplitString(values);
    if (fieldList.size() != valueList.size()) {
        printf("错误：字段和值数量不匹配\n");
        return;
    }

    std::string sql = "UPDATE ";
    sql += GetTableName(tableType);
    sql += " SET ";

    for (size_t i = 0; i < fieldList.size(); ++i) {
        if (i > 0) sql += ", ";
        sql += fieldList[i];
        sql += " = ";
        bool isNumber = !NeedQuotes(tableType, fieldList[i]);
        sql += SqlValue(valueList[i], isNumber);
    }

    if (whereClause && strlen(whereClause) > 0) {
        sql += " WHERE ";
        sql += whereClause;
    }

    printf("[SQL] %s\n", sql.c_str());
    db.UpdateDataBaseInfo(sql.c_str());
}

void QueryTable(DataBase& db, int tableType, const char* fields, const char* values, int clientSock) {
    std::string sql = "SELECT * FROM ";
    sql += GetTableName(tableType);

    auto fieldList = SplitString(fields);
    auto valueList = SplitString(values);
    if (valueList.size() < fieldList.size()) valueList.resize(fieldList.size(), "");

    std::string whereClause;
    for (size_t i = 0; i < fieldList.size(); ++i) {
        if (valueList[i].empty()) continue;
        if (!whereClause.empty()) whereClause += " AND ";
        if (fieldList[i] == "id" || fieldList[i].find("_id") != std::string::npos)
            whereClause += fieldList[i] + " = " + FormatSqlValue(tableType, fieldList[i], valueList[i]);
        else
            whereClause += fieldList[i] + " LIKE " + FormatSqlLikeValue(tableType, fieldList[i], valueList[i]);
    }

    if (!whereClause.empty()) sql += " WHERE " + whereClause;

    printf("[SQL] %s\n", sql.c_str());
    db.QueryDataBaseInfo(clientSock, sql.c_str());

}

// ----------------- TCP 服务器 -----------------

struct ClientInfo {
    int sock;
    sockaddr_in addr;
};

void HandleClient(ClientInfo client) {
    uint8_t buf[10000];
    while (true) {
        ssize_t len = recv(client.sock, (char*)buf, sizeof(buf), 0);
        if (len <= 0) {
            close(client.sock);
            break;
        }

        DbRequestPkg* pkg = (DbRequestPkg*)buf;

        g_pool.AddTask([pkg, client]() {
            switch (pkg->m_ReqType) {
                case REQ_INSERT:
                    InsertToTable(g_dataBase, pkg->m_TableType, pkg->m_FieldList, pkg->m_ValueList);
                    break;
                case REQ_DELETE:
                    DeleteFromTable(g_dataBase, pkg->m_TableType, pkg->m_WhereClause);
                    break;
                case REQ_UPDATE:
                    UpdateTable(g_dataBase, pkg->m_TableType, pkg->m_WhereClause, pkg->m_FieldList, pkg->m_ValueList);
                    break;
                case REQ_QUERY:
                    QueryTable(g_dataBase, pkg->m_TableType, pkg->m_FieldList, pkg->m_ValueList, client.sock);
                    break;
                default:
                    std::cout << "未知请求类型: " << pkg->m_ReqType << std::endl;
                    break;
            }
        });
    }
}

int main() {

    int listenSock = socket(AF_INET, SOCK_STREAM, 0);
    if (listenSock < 0) {
        perror("socket 创建失败");
        return -1;
    }

    int opt = 1;
    setsockopt(listenSock, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(9527);
    addr.sin_addr.s_addr = INADDR_ANY;

    if (bind(listenSock, (sockaddr*)&addr, sizeof(addr)) < 0) {
        perror("绑定端口失败");
        return -1;
    }
    if (listen(listenSock, 16) < 0) {
        perror("监听失败");
        return -1;
    }

    std::cout << "[服务器] 已启动，正在监听端口 ..." << std::endl;

    g_pool.Create(16);

    while (true) {
        sockaddr_in clientAddr;
        socklen_t addrLen = sizeof(clientAddr);
        int clientSock = accept(listenSock, (sockaddr*)&clientAddr, &addrLen);
        if (clientSock < 0) {
            perror("接受客户端连接失败");
            continue;
        }

        char clientIP[INET_ADDRSTRLEN];
        inet_ntop(AF_INET, &clientAddr.sin_addr, clientIP, sizeof(clientIP));
        uint16_t clientPort = ntohs(clientAddr.sin_port);

        std::cout << "[服务器] 新客户端连接: " << clientIP << ":" << clientPort << std::endl;

        std::thread clientThread(HandleClient, ClientInfo{clientSock, clientAddr});
        clientThread.detach();
    }


    close(listenSock);
    return 0;
}
