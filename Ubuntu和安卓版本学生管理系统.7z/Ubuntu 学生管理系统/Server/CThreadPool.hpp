//
// Created by kr on 2025/8/13.
//

#ifndef SERVER_CTHREADPOOL_HPP
#define SERVER_CTHREADPOOL_HPP

#pragma once
#include <queue>
#include <functional>
#include <mutex>
#include <vector>
#include <thread>
#include <cstdint>
#include <condition_variable>

// 线程池类
class CThreadPool
{
    using Task = std::function<void()>;

public:
    CThreadPool() = default;

    ~CThreadPool()
    {
        {
            std::unique_lock<std::mutex> lock(m_mtxForQueue);
            m_stop = true;
        }
        m_cv.notify_all(); // 唤醒所有线程

        for (auto& t : m_threads)
        {
            if (t.joinable())
                t.join();
        }
    }

    // 创建线程池
    void Create(uint32_t nCnt = 4)
    {
        for (size_t i = 0; i < nCnt; i++)
        {
            m_threads.emplace_back(&CThreadPool::ThreadProc, this);
        }
    }

    // 添加任务
    void AddTask(Task task)
    {
        {
            std::lock_guard<std::mutex> lock(m_mtxForQueue);
            m_quTasks.push(task);
        }
        m_cv.notify_one(); // 唤醒一个线程
    }

private:
    void ThreadProc()
    {
        while (true)
        {
            Task task;
            {
                std::unique_lock<std::mutex> lock(m_mtxForQueue);
                m_cv.wait(lock, [this] { return !m_quTasks.empty() || m_stop; });

                if (m_stop && m_quTasks.empty())
                    return;

                task = m_quTasks.front();
                m_quTasks.pop();
            }

            try {
                task();
            }
            catch (...) {
                // 捕获任务异常，防止线程退出
            }
        }
    }

private:
    std::queue<Task> m_quTasks;            // 任务队列
    std::mutex m_mtxForQueue;              // 队列锁
    std::condition_variable m_cv;          // 条件变量
    std::vector<std::thread> m_threads;    // 线程池
    bool m_stop = false;                   // 停止标志
};


#endif //SERVER_CTHREADPOOL_HPP