//
// Created by kr on 2025/8/13.
//

#ifndef SERVER_STUDENTDATABASE_H
#define SERVER_STUDENTDATABASE_H


#pragma once
#include <mysql/mysql.h>
#include <stdio.h>
#include <string>
#include <vector>
#include <mutex>
#include <unistd.h> // write, close for TCP

class DataBase {
public:
    DataBase() {
        m_pMysql = mysql_init(nullptr);
        if (!m_pMysql) {
            printf("Error initializing MySQL\n");
            return;
        }

        if (!mysql_real_connect(m_pMysql, "127.0.0.1", "kr", "toortoor", nullptr, 3306, nullptr, 0)) {
            printf("Error connecting to MySQL: %s\n", mysql_error(m_pMysql));
            return;
        }

        // 创建数据库并选择
        Execute("CREATE DATABASE IF NOT EXISTS db_SchoolInfoManagement DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci");
        Execute("USE db_SchoolInfoManagement");
        mysql_set_character_set(m_pMysql, "utf8mb4");

        // 创建表
        Execute(R"(CREATE TABLE IF NOT EXISTS student (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    name VARCHAR(50) NOT NULL
                ))");
        Execute(R"(CREATE TABLE IF NOT EXISTS class (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    name VARCHAR(50) NOT NULL UNIQUE
                ))");
        Execute(R"(CREATE TABLE IF NOT EXISTS student_class_map (
                    student_id INT PRIMARY KEY,
                    class_id INT NOT NULL,
                    FOREIGN KEY(student_id) REFERENCES student(id) ON DELETE CASCADE,
                    FOREIGN KEY(class_id) REFERENCES class(id) ON DELETE CASCADE
                ))");
        Execute(R"(CREATE TABLE IF NOT EXISTS course (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    name VARCHAR(50) NOT NULL
                ))");
        Execute(R"(CREATE TABLE IF NOT EXISTS enroll (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    student_id INT NOT NULL,
                    course_id INT NOT NULL,
                    score DECIMAL(5,2),
                    FOREIGN KEY(student_id) REFERENCES student(id) ON DELETE CASCADE,
                    FOREIGN KEY(course_id) REFERENCES course(id) ON DELETE CASCADE,
                    UNIQUE(student_id, course_id)
                ))");
        Execute(R"(CREATE OR REPLACE VIEW student_full_info AS
                    SELECT s.id AS student_id, s.name AS student_name, c.name AS class_name,
                           crs.name AS course_name, e.score AS score
                    FROM student s
                    LEFT JOIN student_class_map scm ON s.id = scm.student_id
                    LEFT JOIN class c ON scm.class_id = c.id
                    LEFT JOIN enroll e ON s.id = e.student_id
                    LEFT JOIN course crs ON e.course_id = crs.id)");
    }

    ~DataBase() {
        if (m_pMysql) mysql_close(m_pMysql);
    }

    // 增删改接口
    int ExecuteSQL(const char* sql) {
        if (mysql_query(m_pMysql, sql)) {
            printf("SQL ERROR: %s\n", mysql_error(m_pMysql));
            return -1;
        }
        return 1;
    }

    int AddDataBaseInfo(const char* sql) { return ExecuteSQL(sql); }
    int DeleteDataBaseInfo(const char* sql) { return ExecuteSQL(sql); }
    int UpdateDataBaseInfo(const char* sql) { return ExecuteSQL(sql); }

    // 查询接口：将结果通过 TCP socket 发送给客户端
    int QueryDataBaseInfo(int clientSock, const char* sql) {
        printf("[SQL] 执行: %s\n", sql);

        if (mysql_query(m_pMysql, sql)) {
            printf("[ERROR] QueryDataBaseInfo: %s\n", mysql_error(m_pMysql));
            return -1;
        }

        MYSQL_RES* result = mysql_store_result(m_pMysql);
        if (!result) {
            printf("[ERROR] mysql_store_result 返回空\n");
            return -1;
        }

        int num_fields = mysql_num_fields(result);
        MYSQL_FIELD* fields = mysql_fetch_fields(result);

        std::string sendStr;
        printf("[RESULT] 列名: ");
        for (int i = 0; i < num_fields; i++) {
            sendStr.append(fields[i].name);
            printf("%s\t", fields[i].name);
            if (i < num_fields - 1) sendStr.append("\t");
        }
        sendStr.append("\r\n");
        printf("\n");

        MYSQL_ROW row;
        while ((row = mysql_fetch_row(result))) {
            printf("[RESULT] 数据行: ");
            for (int i = 0; i < num_fields; i++) {
                const char* val = row[i] ? row[i] : "NULL";
                sendStr.append(val);
                printf("%s\t", val);
                if (i < num_fields - 1) sendStr.append("\t");
            }
            sendStr.append("\n");  // 改成 \n
            printf("\n");
        }

        mysql_free_result(result);

        // 通过 TCP socket 发送
        ssize_t sent = write(clientSock, sendStr.c_str(), sendStr.size());
        if (sent <= 0) {
            perror("[ERROR] send failed");
        } else {
            printf("[INFO] 已发送 %zd 字节到客户端\n", sent);
        }

        return 1;
    }


private:
    MYSQL* m_pMysql = nullptr;

    void Execute(const std::string& sql) {
        if (mysql_query(m_pMysql, sql.c_str())) {
            printf("Error executing SQL: %s\n", mysql_error(m_pMysql));
        }
    }
};



#endif //SERVER_STUDENTDATABASE_H