#pragma once
#include <cstring>
#include <cstdint>

// 字符串长度定义
#define NAME_LEN 64
#define FIELD_STR_LEN 256
#define VALUE_STR_LEN 1024

// 请求类型
#define REQ_INSERT       1000
#define REQ_DELETE       1001
#define REQ_UPDATE       1002
#define REQ_QUERY        1003

// 表类型
#define TABLE_STUDENT          2001
#define TABLE_CLASS            2002
#define TABLE_COURSE           2003
#define TABLE_ENROLL           2004
#define TABLE_STUDENT_CLASS    2005
#define TABLE_VIEW_FULLINFO    2006

#pragma pack(push, 1) // 避免内存对齐填充

// 客户端请求包
struct DbRequestPkg
{
    int32_t m_ReqType = 0;           // 操作类型
    int32_t m_TableType = 0;         // 表类型

    char m_FieldList[FIELD_STR_LEN] = { 0 };    // 字段列表
    char m_ValueList[VALUE_STR_LEN] = { 0 };    // 对应值列表
    char m_WhereClause[VALUE_STR_LEN] = { 0 };  // WHERE 条件

    DbRequestPkg() = default;

    DbRequestPkg(int32_t reqType, int32_t tableType, const char* fields, const char* values, const char* where = "")
    {
        m_ReqType = reqType;
        m_TableType = tableType;
        if (fields) strncpy(m_FieldList, fields, sizeof(m_FieldList) - 1);
        if (values) strncpy(m_ValueList, values, sizeof(m_ValueList) - 1);
        if (where)  strncpy(m_WhereClause, where, sizeof(m_WhereClause) - 1);
    }
};

// 服务器响应包
struct DbResponsePkg
{
    int32_t m_ReqType = 0;
    int32_t m_TableType = 0;
    int32_t m_IsSucceed = 0;       // 1 成功 / 0 失败
    int32_t m_nResultCount = 0;    // 查询结果条数，仅查询有效

    DbResponsePkg() = default;
};

// 查询结果结构体（按需发送数组）
struct QueryStudentRow
{
    int32_t m_StudentID = 0;
    char m_StudentName[NAME_LEN] = { 0 };
};

struct QueryClassRow
{
    int32_t m_ClassID = 0;
    char m_ClassName[NAME_LEN] = { 0 };
};

struct QueryCourseRow
{
    int32_t m_CourseID = 0;
    char m_CourseName[NAME_LEN] = { 0 };
};

struct QueryEnrollRow
{
    int32_t id = 0;
    int32_t student_id = 0;
    int32_t course_id = 0;
    float score = 0.0f;
};

struct QueryStudentClassRow
{
    int32_t student_id = 0;
    int32_t class_id = 0;
};

#pragma pack(pop)
