//
// Created by kr on 2025/8/13.
//

#ifndef SERVER_MAIN_H
#define SERVER_MAIN_H


#pragma once
#include <string>

// SQL 辅助函数
std::string FormatSqlValue(int tableType, const std::string& field, const std::string& val);
std::string FormatSqlLikeValue(int tableType, const std::string& field, const std::string& value);

// TCP 客户端 socket
extern int g_clientSock;  // 全局客户端 socket，或者每个线程单独传递


#endif //SERVER_MAIN_H