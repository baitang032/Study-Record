#include <jni.h>
#include <string>
#include <sys/types.h>
#include <sys/socket.h>
#include <linux/in.h>
#include <arpa/inet.h>
#include <linux/un.h>
#include <android/log.h>
#include <unistd.h>
#include <vector>
#include "Package.h"
#include <sstream>
#include <pthread.h>
#define  LOGV(...) __android_log_print(ANDROID_LOG_VERBOSE, "kr", __VA_ARGS__)
// 服务器信息
#define SERVER_IP   "192.168.124.6"
#define SERVER_PORT 9527

static int g_sock_fd = -1;
static pthread_mutex_t g_sock_mutex = PTHREAD_MUTEX_INITIALIZER;

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_client_MainActivity_stringFromJNI(
        JNIEnv* env,
        jobject /* this */) {
    std::string hello = "Hello from C++";
    return env->NewStringUTF(hello.c_str());
}

struct StudentRaw {
    char szID[64];
    char szName[64];
};

int createTcpConnection() {
    // 1. 创建 TCP 套接字
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        LOGV("socket 创建失败");
        return -1;
    }

    // 2. 填充服务器地址
    sockaddr_in serverAddr{};
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(SERVER_PORT);
    serverAddr.sin_addr.s_addr = inet_addr(SERVER_IP);

    // 3. 连接服务器
    if (connect(sock, (sockaddr*)&serverAddr, sizeof(serverAddr)) < 0) {
        LOGV("连接服务器失败");
        close(sock);
        return -1;
    }

    LOGV("连接服务器成功");
    return sock;
}
// 学生表
extern "C"
JNIEXPORT jobjectArray JNICALL
Java_com_example_client_TableActivity_getAllStudentsNative(JNIEnv *env, jobject thiz) {
    LOGV("[getAllStudentsNative] 开始执行");

    // 1. 确保 TCP 连接安全
    pthread_mutex_lock(&g_sock_mutex);
    if (g_sock_fd < 0) {
        g_sock_fd = createTcpConnection();
        if (g_sock_fd < 0) {
            LOGV("[getAllStudentsNative] TCP 连接失败");
            pthread_mutex_unlock(&g_sock_mutex);
            return nullptr;
        }
        LOGV("[getAllStudentsNative] TCP 连接成功, fd=%d", g_sock_fd);
    }
    pthread_mutex_unlock(&g_sock_mutex);

    // 2. 构造查询请求包
    DbRequestPkg pkg{};
    pkg.m_ReqType = REQ_QUERY;
    pkg.m_TableType = TABLE_STUDENT;
    strncpy(pkg.m_FieldList, "id,name", sizeof(pkg.m_FieldList)-1);
    strncpy(pkg.m_ValueList, ",", sizeof(pkg.m_ValueList)-1);

    // 3. 发送请求
    pthread_mutex_lock(&g_sock_mutex);
    ssize_t sent = send(g_sock_fd, &pkg, sizeof(pkg), 0);
    if (sent <= 0) {
        LOGV("[getAllStudentsNative] 发送请求失败, sent=%zd", sent);
        close(g_sock_fd);
        g_sock_fd = -1;
        pthread_mutex_unlock(&g_sock_mutex);
        return nullptr;
    }
    LOGV("[getAllStudentsNative] 请求发送成功, sent=%zd", sent);

    char buffer[4096] = {0};
    ssize_t n = recv(g_sock_fd, buffer, sizeof(buffer)-1, 0);
    pthread_mutex_unlock(&g_sock_mutex);

    if (n <= 0) {
        LOGV("[getAllStudentsNative] 接收数据失败, n=%zd", n);
        close(g_sock_fd);
        g_sock_fd = -1;
        return nullptr;
    }
    buffer[n] = '\0';
    close(g_sock_fd);
    g_sock_fd = -1;
    LOGV("[getAllStudentsNative] 接收到数据长度: %zd", n);

    // 4. 拆行
    std::vector<std::string> lines;
    char* saveptr = nullptr;
    char* line = strtok_r(buffer, "\r\n", &saveptr);
    while (line) {
        if (strlen(line) > 0) lines.push_back(line);
        line = strtok_r(nullptr, "\r\n", &saveptr);
    }

    if (lines.empty()) {
        LOGV("[getAllStudentsNative] 没有有效数据行");
        return nullptr;
    }
    LOGV("[getAllStudentsNative] 收到 %zu 行数据", lines.size());

    // 5. 找列索引
    int idx_id = -1, idx_name = -1;
    {
        std::stringstream ss0(lines[0]);
        std::string col;
        int i = 0;
        while (std::getline(ss0, col, '\t')) {
            if (col == "id") idx_id = i;
            if (col == "name") idx_name = i;
            ++i;
        }
    }
    LOGV("[getAllStudentsNative] 列索引 id=%d, name=%d", idx_id, idx_name);
    if (idx_id == -1 || idx_name == -1) return nullptr;

    // 6. 创建 Java Student 对象数组
    jclass clsStudent = env->FindClass("com/example/client/Student");
    if (!clsStudent) {
        LOGV("[getAllStudentsNative] 找不到 Java 类 Student");
        return nullptr;
    }

    jmethodID ctor = env->GetMethodID(clsStudent, "<init>", "(ILjava/lang/String;)V");
    if (!ctor) {
        LOGV("[getAllStudentsNative] 找不到构造函数");
        return nullptr;
    }

    jobjectArray arr = env->NewObjectArray(lines.size()-1, clsStudent, nullptr);
    if (!arr) {
        LOGV("[getAllStudentsNative] 创建对象数组失败");
        return nullptr;
    }

    // 7. 遍历数据行
    for (size_t i = 1; i < lines.size(); ++i) {
        std::stringstream ss(lines[i]);
        std::string field;
        std::vector<std::string> fields;
        while (std::getline(ss, field, '\t')) fields.push_back(field);

        if (fields.size() <= std::max(idx_id, idx_name)) {
            LOGV("[getAllStudentsNative] 第 %zu 行字段数量不足, 跳过", i);
            continue;
        }

        int id = 0;
        try { id = std::stoi(fields[idx_id]); } catch (...) { id = 0; }

        jstring name = env->NewStringUTF(fields[idx_name].c_str());
        if (!name) {
            LOGV("[getAllStudentsNative] 第 %zu 行创建 jstring 失败", i);
            continue;
        }

        jobject stuObj = env->NewObject(clsStudent, ctor, id, name);
        if (!stuObj) {
            LOGV("[getAllStudentsNative] 第 %zu 行创建对象失败", i);
            continue;
        }

        env->SetObjectArrayElement(arr, i-1, stuObj);
    }

    LOGV("[getAllStudentsNative] 执行结束, 返回对象数组大小: %zu", lines.size()-1);
    return arr;
}


// 获取班级表
extern "C"
JNIEXPORT jobjectArray JNICALL
Java_com_example_client_TableActivity_getAllClassesNative(JNIEnv *env, jobject thiz) {
    LOGV("[getAllClassesNative] 开始执行");

    // 1. 确保连接安全
    pthread_mutex_lock(&g_sock_mutex);
    if (g_sock_fd < 0) {
        g_sock_fd = createTcpConnection();
        if (g_sock_fd < 0) {
            LOGV("[getAllClassesNative] TCP 连接失败");
            pthread_mutex_unlock(&g_sock_mutex);
            return nullptr;
        }
        LOGV("[getAllClassesNative] TCP 连接成功, fd=%d", g_sock_fd);
    }

    // 2. 构造查询请求包
    DbRequestPkg pkg{};
    pkg.m_ReqType = REQ_QUERY;
    pkg.m_TableType = TABLE_CLASS;
    strncpy(pkg.m_FieldList, "id,name", sizeof(pkg.m_FieldList)-1);
    strncpy(pkg.m_ValueList, ",", sizeof(pkg.m_ValueList)-1);

    // 3. 发送请求包
    ssize_t sent = send(g_sock_fd, &pkg, sizeof(pkg), 0);
    if (sent <= 0) {
        LOGV("[getAllClassesNative] 发送请求失败, sent=%zd", sent);
        close(g_sock_fd);
        g_sock_fd = -1;
        pthread_mutex_unlock(&g_sock_mutex);
        return nullptr;
    }
    LOGV("[getAllClassesNative] 请求发送成功, sent=%zd", sent);

    char buffer[4096] = {0};
    ssize_t n = recv(g_sock_fd, buffer, sizeof(buffer)-1, 0);
    pthread_mutex_unlock(&g_sock_mutex);

    if (n <= 0) {
        LOGV("[getAllClassesNative] 接收数据失败, n=%zd", n);
        close(g_sock_fd);
        g_sock_fd = -1;
        return nullptr;
    }
    buffer[n] = '\0';
    close(g_sock_fd);
    g_sock_fd = -1;
    LOGV("[getAllClassesNative] 接收到数据长度: %zd", n);

    // 4. 拆行
    std::vector<std::string> lines;
    char* saveptr = nullptr;
    char* line = strtok_r(buffer, "\r\n", &saveptr);
    while (line) {
        if (strlen(line) > 0) lines.push_back(line);
        line = strtok_r(nullptr, "\r\n", &saveptr);
    }
    if (lines.empty()) {
        LOGV("[getAllClassesNative] 没有有效数据行");
        return nullptr;
    }
    LOGV("[getAllClassesNative] 收到 %zu 行数据", lines.size());

    // 5. 找列索引
    int idx_id = -1, idx_name = -1;
    {
        std::stringstream ss0(lines[0]);
        std::string col;
        int i = 0;
        while (std::getline(ss0, col, '\t')) {
            if (col == "id") idx_id = i;
            if (col == "name") idx_name = i;
            ++i;
        }
    }
    LOGV("[getAllClassesNative] 列索引 id=%d, name=%d", idx_id, idx_name);
    if (idx_id == -1 || idx_name == -1) return nullptr;

    // 6. 创建 Java 对象数组
    jclass cls = env->FindClass("com/example/client/Class");
    if (!cls) {
        LOGV("[getAllClassesNative] 找不到 Java 类 Class");
        return nullptr;
    }

    jmethodID ctor = env->GetMethodID(cls, "<init>", "(ILjava/lang/String;)V");
    if (!ctor) {
        LOGV("[getAllClassesNative] 找不到构造函数");
        return nullptr;
    }

    jobjectArray arr = env->NewObjectArray(lines.size() - 1, cls, nullptr);
    if (!arr) {
        LOGV("[getAllClassesNative] 创建对象数组失败");
        return nullptr;
    }

    // 7. 遍历数据行
    for (size_t j = 1; j < lines.size(); ++j) {
        std::stringstream ss(lines[j]);
        std::vector<std::string> fields;
        std::string f;
        while (std::getline(ss, f, '\t')) fields.push_back(f);

        if (fields.size() <= std::max(idx_id, idx_name)) {
            LOGV("[getAllClassesNative] 第 %zu 行字段数量不足, 跳过", j);
            continue;
        }

        int id = 0;
        try {
            id = std::stoi(fields[idx_id]);
        } catch (...) {
            LOGV("[getAllClassesNative] 第 %zu 行 id 转换失败", j);
            id = 0;
        }

        jstring name = env->NewStringUTF(fields[idx_name].c_str());
        if (!name) {
            LOGV("[getAllClassesNative] 第 %zu 行创建 jstring 失败", j);
            continue;
        }

        jobject obj = env->NewObject(cls, ctor, id, name);
        if (!obj) {
            LOGV("[getAllClassesNative] 第 %zu 行创建对象失败", j);
            continue;
        }

        env->SetObjectArrayElement(arr, j - 1, obj);
    }

    LOGV("[getAllClassesNative] 执行结束, 返回对象数组大小: %zu", lines.size() - 1);
    return arr;
}

// 获取课程表
extern "C"
JNIEXPORT jobjectArray JNICALL
Java_com_example_client_TableActivity_getAllCoursesNative(JNIEnv *env, jobject thiz) {
    LOGV("[getAllCoursesNative] 开始执行");

    // 1. 确保连接安全
    pthread_mutex_lock(&g_sock_mutex);
    if (g_sock_fd < 0) {
        g_sock_fd = createTcpConnection();
        if (g_sock_fd < 0) {
            LOGV("[getAllCoursesNative] TCP 连接失败");
            pthread_mutex_unlock(&g_sock_mutex);
            return nullptr;
        }
        LOGV("[getAllCoursesNative] TCP 连接成功, fd=%d", g_sock_fd);
    }

    // 2. 构造查询请求包
    DbRequestPkg pkg{};
    pkg.m_ReqType = REQ_QUERY;
    pkg.m_TableType = TABLE_COURSE;  // 2003
    strncpy(pkg.m_FieldList, "id,name", sizeof(pkg.m_FieldList)-1);
    strncpy(pkg.m_ValueList, ",", sizeof(pkg.m_ValueList)-1);

    // 3. 发送请求
    ssize_t sent = send(g_sock_fd, &pkg, sizeof(pkg), 0);
    if (sent <= 0) {
        LOGV("[getAllCoursesNative] 发送请求失败, sent=%zd", sent);
        close(g_sock_fd);
        g_sock_fd = -1;
        pthread_mutex_unlock(&g_sock_mutex);
        return nullptr;
    }
    LOGV("[getAllCoursesNative] 请求发送成功, sent=%zd", sent);

    char buffer[4096] = {0};
    ssize_t n = recv(g_sock_fd, buffer, sizeof(buffer) - 1, 0);
    pthread_mutex_unlock(&g_sock_mutex);

    if (n <= 0) {
        LOGV("[getAllCoursesNative] 接收数据失败, n=%zd", n);
        close(g_sock_fd);
        g_sock_fd = -1;
        return nullptr;
    }
    buffer[n] = '\0';
    close(g_sock_fd);
    g_sock_fd = -1;
    LOGV("[getAllCoursesNative] 接收到数据长度: %zd", n);

    // 4. 拆行
    std::vector<std::string> lines;
    char* saveptr = nullptr;
    char* line = strtok_r(buffer, "\r\n", &saveptr);
    while (line) {
        if (strlen(line) > 0) lines.push_back(line);
        line = strtok_r(nullptr, "\r\n", &saveptr);
    }
    if (lines.empty()) {
        LOGV("[getAllCoursesNative] 没有有效数据行");
        return nullptr;
    }
    LOGV("[getAllCoursesNative] 收到 %zu 行数据", lines.size());

    // 5. 找列索引
    int idx_id = -1, idx_name = -1;
    {
        std::stringstream ss0(lines[0]);
        std::string col;
        int i = 0;
        while (std::getline(ss0, col, '\t')) {
            if (col == "id") idx_id = i;
            if (col == "name") idx_name = i;
            ++i;
        }
    }
    LOGV("[getAllCoursesNative] 列索引 id=%d, name=%d", idx_id, idx_name);
    if (idx_id == -1 || idx_name == -1) return nullptr;

    // 6. 创建 Java 对象数组
    jclass cls = env->FindClass("com/example/client/Course");
    if (!cls) {
        LOGV("[getAllCoursesNative] 找不到 Java 类 Course");
        return nullptr;
    }

    jmethodID ctor = env->GetMethodID(cls, "<init>", "(ILjava/lang/String;)V");
    if (!ctor) {
        LOGV("[getAllCoursesNative] 找不到构造函数");
        return nullptr;
    }

    jobjectArray arr = env->NewObjectArray(lines.size() - 1, cls, nullptr);
    if (!arr) {
        LOGV("[getAllCoursesNative] 创建对象数组失败");
        return nullptr;
    }

    // 7. 遍历数据行
    for (size_t j = 1; j < lines.size(); ++j) {
        std::stringstream ss(lines[j]);
        std::vector<std::string> fields;
        std::string f;
        while (std::getline(ss, f, '\t')) fields.push_back(f);

        if (fields.size() <= std::max(idx_id, idx_name)) {
            LOGV("[getAllCoursesNative] 第 %zu 行字段数量不足, 跳过", j);
            continue;
        }

        int id = 0;
        try {
            id = std::stoi(fields[idx_id]);
        } catch (...) {
            LOGV("[getAllCoursesNative] 第 %zu 行 id 转换失败", j);
            id = 0;
        }

        jstring name = env->NewStringUTF(fields[idx_name].c_str());
        if (!name) {
            LOGV("[getAllCoursesNative] 第 %zu 行创建 jstring 失败", j);
            continue;
        }

        jobject obj = env->NewObject(cls, ctor, id, name);
        if (!obj) {
            LOGV("[getAllCoursesNative] 第 %zu 行创建对象失败", j);
            continue;
        }

        env->SetObjectArrayElement(arr, j - 1, obj);
    }

    LOGV("[getAllCoursesNative] 执行结束, 返回对象数组大小: %zu", lines.size() - 1);
    return arr;
}

// 获取选课表
extern "C"
JNIEXPORT jobjectArray JNICALL
Java_com_example_client_TableActivity_getAllEnrollsNative(JNIEnv *env, jobject thiz) {
    LOGV("[getAllEnrollsNative] 开始执行");

    // 1. 确保 TCP 连接安全
    pthread_mutex_lock(&g_sock_mutex);
    if (g_sock_fd < 0) {
        g_sock_fd = createTcpConnection();
        if (g_sock_fd < 0) {
            LOGV("[getAllEnrollsNative] TCP 连接失败");
            pthread_mutex_unlock(&g_sock_mutex);
            return nullptr;
        }
        LOGV("[getAllEnrollsNative] TCP 连接成功, fd=%d", g_sock_fd);
    }

    // 2. 构造查询请求包
    DbRequestPkg pkg{};
    pkg.m_ReqType = REQ_QUERY;
    pkg.m_TableType = TABLE_ENROLL; // 2004
    strncpy(pkg.m_FieldList, "id,student_id,course_id,score", sizeof(pkg.m_FieldList) - 1);
    strncpy(pkg.m_ValueList, ",,,", sizeof(pkg.m_ValueList) - 1);

    // 3. 发送请求
    ssize_t sent = send(g_sock_fd, &pkg, sizeof(pkg), 0);
    if (sent <= 0) {
        LOGV("[getAllEnrollsNative] 发送请求失败, sent=%zd", sent);
        close(g_sock_fd);
        g_sock_fd = -1;
        pthread_mutex_unlock(&g_sock_mutex);
        return nullptr;
    }
    LOGV("[getAllEnrollsNative] 请求发送成功, sent=%zd", sent);

    char buffer[4096] = {0};
    ssize_t n = recv(g_sock_fd, buffer, sizeof(buffer) - 1, 0);
    pthread_mutex_unlock(&g_sock_mutex);

    if (n <= 0) {
        LOGV("[getAllEnrollsNative] 接收数据失败, n=%zd", n);
        close(g_sock_fd);
        g_sock_fd = -1;
        return nullptr;
    }
    buffer[n] = '\0';
    close(g_sock_fd);
    g_sock_fd = -1;
    LOGV("[getAllEnrollsNative] 接收到数据长度: %zd", n);

    // 4. 拆行
    std::vector<std::string> lines;
    char* saveptr = nullptr;
    char* line = strtok_r(buffer, "\r\n", &saveptr);
    while (line) {
        if (strlen(line) > 0) lines.push_back(line);
        line = strtok_r(nullptr, "\r\n", &saveptr);
    }
    if (lines.empty()) {
        LOGV("[getAllEnrollsNative] 没有有效数据行");
        return nullptr;
    }
    LOGV("[getAllEnrollsNative] 收到 %zu 行数据", lines.size());

    // 5. 找列索引
    int idx_id = -1, idx_student = -1, idx_course = -1, idx_score = -1;
    {
        std::stringstream ss0(lines[0]);
        std::string col;
        int i = 0;
        while (std::getline(ss0, col, '\t')) {
            if (col == "id") idx_id = i;
            if (col == "student_id") idx_student = i;
            if (col == "course_id") idx_course = i;
            if (col == "score") idx_score = i;
            ++i;
        }
    }
    LOGV("[getAllEnrollsNative] 列索引 id=%d, student=%d, course=%d, score=%d", idx_id, idx_student, idx_course, idx_score);
    if (idx_id == -1 || idx_student == -1 || idx_course == -1 || idx_score == -1) return nullptr;

    // 6. 创建 Java 对象数组
    jclass cls = env->FindClass("com/example/client/Enroll");
    if (!cls) {
        LOGV("[getAllEnrollsNative] 找不到 Java 类 Enroll");
        return nullptr;
    }

    jmethodID ctor = env->GetMethodID(cls, "<init>", "(IIID)V");
    if (!ctor) {
        LOGV("[getAllEnrollsNative] 找不到构造函数");
        return nullptr;
    }

    jobjectArray arr = env->NewObjectArray(lines.size() - 1, cls, nullptr);
    if (!arr) {
        LOGV("[getAllEnrollsNative] 创建对象数组失败");
        return nullptr;
    }

    // 7. 遍历数据行
    for (size_t j = 1; j < lines.size(); ++j) {
        std::stringstream ss(lines[j]);
        std::vector<std::string> fields;
        std::string f;
        while (std::getline(ss, f, '\t')) fields.push_back(f);

        int id = 0, studentId = 0, courseId = 0;
        double score = 0.0;

        try {
            if (idx_id >= 0 && idx_id < fields.size() && !fields[idx_id].empty())
                id = std::stoi(fields[idx_id]);
            if (idx_student >= 0 && idx_student < fields.size() && !fields[idx_student].empty())
                studentId = std::stoi(fields[idx_student]);
            if (idx_course >= 0 && idx_course < fields.size() && !fields[idx_course].empty())
                courseId = std::stoi(fields[idx_course]);
            if (idx_score >= 0 && idx_score < fields.size() && !fields[idx_score].empty())
                score = std::stod(fields[idx_score]);
        } catch (...) {
            LOGV("[getAllEnrollsNative] 第 %zu 行数据解析异常, 跳过", j);
            continue; // 异常行跳过
        }

        jobject obj = env->NewObject(cls, ctor, id, studentId, courseId, score);
        if (!obj) {
            LOGV("[getAllEnrollsNative] 第 %zu 行创建对象失败", j);
            continue;
        }

        env->SetObjectArrayElement(arr, j - 1, obj);
    }

    LOGV("[getAllEnrollsNative] 执行结束, 返回对象数组大小: %zu", lines.size() - 1);
    return arr;
}

// 获取学生班级归属
extern "C"
JNIEXPORT jobjectArray JNICALL
Java_com_example_client_TableActivity_getAllStudentClassesNative(JNIEnv *env, jobject thiz){
    LOGV("[getAllStudentClassesNative] 开始执行");

    // 1. 确保 TCP 连接安全
    pthread_mutex_lock(&g_sock_mutex);
    if (g_sock_fd < 0) {
        g_sock_fd = createTcpConnection();
        if (g_sock_fd < 0) {
            LOGV("[getAllStudentClassesNative] TCP 连接失败");
            pthread_mutex_unlock(&g_sock_mutex);
            return nullptr;
        }
        LOGV("[getAllStudentClassesNative] TCP 连接成功, fd=%d", g_sock_fd);
    }

    // 2. 构造查询请求包
    DbRequestPkg pkg{};
    pkg.m_ReqType = REQ_QUERY;
    pkg.m_TableType = TABLE_STUDENT_CLASS; // 2005
    strncpy(pkg.m_FieldList, "student_id,class_id", sizeof(pkg.m_FieldList)-1);
    strncpy(pkg.m_ValueList, ",", sizeof(pkg.m_ValueList)-1);

    // 3. 发送请求
    ssize_t sent = send(g_sock_fd, &pkg, sizeof(pkg), 0);
    if (sent <= 0) {
        LOGV("[getAllStudentClassesNative] 发送请求失败, sent=%zd", sent);
        close(g_sock_fd);
        g_sock_fd = -1;
        pthread_mutex_unlock(&g_sock_mutex);
        return nullptr;
    }
    LOGV("[getAllStudentClassesNative] 请求发送成功, sent=%zd", sent);

    char buffer[4096] = {0};
    ssize_t n = recv(g_sock_fd, buffer, sizeof(buffer)-1, 0);
    pthread_mutex_unlock(&g_sock_mutex);

    if (n <= 0) {
        LOGV("[getAllStudentClassesNative] 接收数据失败, n=%zd", n);
        close(g_sock_fd);
        g_sock_fd = -1;
        return nullptr;
    }
    buffer[n] = '\0';
    close(g_sock_fd);
    g_sock_fd = -1;
    LOGV("[getAllStudentClassesNative] 接收到数据长度: %zd", n);

    // 4. 拆行
    std::vector<std::string> lines;
    char* saveptr = nullptr;
    char* line = strtok_r(buffer, "\r\n", &saveptr);
    while (line) {
        if (strlen(line) > 0) lines.push_back(line);
        line = strtok_r(nullptr, "\r\n", &saveptr);
    }
    if (lines.empty()) {
        LOGV("[getAllStudentClassesNative] 没有收到有效行");
        return nullptr;
    }
    LOGV("[getAllStudentClassesNative] 收到 %zu 行数据", lines.size());

    // 5. 找列索引
    int idx_student = -1, idx_class = -1;
    {
        std::stringstream ss0(lines[0]);
        std::string col;
        int i = 0;
        while (std::getline(ss0, col, '\t')) {
            if (col == "student_id") idx_student = i;
            if (col == "class_id") idx_class = i;
            ++i;
        }
    }
    LOGV("[getAllStudentClassesNative] 列索引 student=%d, class=%d", idx_student, idx_class);
    if (idx_student == -1 || idx_class == -1) return nullptr;

    // 6. 创建 Java 对象数组
    jclass cls = env->FindClass("com/example/client/StudentClassMap");
    if (!cls) {
        LOGV("[getAllStudentClassesNative] 找不到 Java 类 StudentClassMap");
        return nullptr;
    }

    jmethodID ctor = env->GetMethodID(cls, "<init>", "(II)V");
    if (!ctor) {
        LOGV("[getAllStudentClassesNative] 找不到构造函数");
        return nullptr;
    }

    jobjectArray arr = env->NewObjectArray(lines.size() - 1, cls, nullptr);
    if (!arr) {
        LOGV("[getAllStudentClassesNative] 创建 Java 对象数组失败");
        return nullptr;
    }

    // 7. 遍历数据行
    for (size_t j = 1; j < lines.size(); ++j) {
        std::stringstream ss(lines[j]);
        std::vector<std::string> fields;
        std::string f;
        while (std::getline(ss, f, '\t')) fields.push_back(f);

        int studentId = 0, classId = 0;
        try {
            if (idx_student >= 0 && idx_student < fields.size() && !fields[idx_student].empty())
                studentId = std::stoi(fields[idx_student]);
            if (idx_class >= 0 && idx_class < fields.size() && !fields[idx_class].empty())
                classId = std::stoi(fields[idx_class]);
        } catch (...) {
            LOGV("[getAllStudentClassesNative] 第 %zu 行数据解析异常, 跳过", j);
            continue; // 跳过异常行
        }

        jobject obj = env->NewObject(cls, ctor, studentId, classId);
        if (!obj) {
            LOGV("[getAllStudentClassesNative] 第 %zu 行创建对象失败", j);
            continue;
        }

        env->SetObjectArrayElement(arr, j - 1, obj);
    }

    LOGV("[getAllStudentClassesNative] 执行结束, 返回对象数组大小: %zu", lines.size() - 1);
    return arr;
}


// 获取综合视图
extern "C"
JNIEXPORT jobjectArray JNICALL
Java_com_example_client_TableActivity_getAllQueryInputsNative(JNIEnv *env, jobject thiz){
    LOGV("[getAllQueryInputsNative] 开始执行");

    // 1. 确保 TCP 连接安全
    pthread_mutex_lock(&g_sock_mutex);
    if (g_sock_fd < 0) {
        g_sock_fd = createTcpConnection();
        if (g_sock_fd < 0) {
            LOGV("[getAllQueryInputsNative] TCP 连接失败");
            pthread_mutex_unlock(&g_sock_mutex);
            return nullptr;
        }
        LOGV("[getAllQueryInputsNative] TCP 连接成功, fd=%d", g_sock_fd);
    }

    // 2. 构造查询请求包
    DbRequestPkg pkg{};
    pkg.m_ReqType = REQ_QUERY;
    pkg.m_TableType = TABLE_VIEW_FULLINFO; // 2006
    strncpy(pkg.m_FieldList, "student_id,student_name,class_id,class_name,course_id,course_name,score", sizeof(pkg.m_FieldList) - 1);
    strncpy(pkg.m_ValueList, ",,,,,,", sizeof(pkg.m_ValueList) - 1);

    // 3. 发送请求
    ssize_t sent = send(g_sock_fd, &pkg, sizeof(pkg), 0);
    if (sent <= 0) {
        LOGV("[getAllQueryInputsNative] 发送请求失败, sent=%zd", sent);
        close(g_sock_fd);
        g_sock_fd = -1;
        pthread_mutex_unlock(&g_sock_mutex);
        return nullptr;
    }
    LOGV("[getAllQueryInputsNative] 请求发送成功, sent=%zd", sent);

    char buffer[8192] = {0};
    ssize_t n = recv(g_sock_fd, buffer, sizeof(buffer) - 1, 0);
    pthread_mutex_unlock(&g_sock_mutex);

    if (n <= 0) {
        LOGV("[getAllQueryInputsNative] 接收数据失败, n=%zd", n);
        close(g_sock_fd);
        g_sock_fd = -1;
        return nullptr;
    }
    buffer[n] = '\0';
    close(g_sock_fd);
    g_sock_fd = -1;
    LOGV("[getAllQueryInputsNative] 接收到数据长度: %zd", n);

    // 4. 拆行
    std::vector<std::string> lines;
    char* saveptr = nullptr;
    char* line = strtok_r(buffer, "\r\n", &saveptr);
    while (line) {
        if (strlen(line) > 0) lines.push_back(line);
        line = strtok_r(nullptr, "\r\n", &saveptr);
    }
    if (lines.empty()) {
        LOGV("[getAllQueryInputsNative] 没有收到有效行");
        return nullptr;
    }
    LOGV("[getAllQueryInputsNative] 收到 %zu 行数据", lines.size());

    // 5. 找列索引
    int idx_studentId = -1, idx_studentName = -1, idx_classId = -1, idx_className = -1,
            idx_courseId = -1, idx_courseName = -1, idx_score = -1;
    {
        std::stringstream ss0(lines[0]);
        std::string col;
        int i = 0;
        while (std::getline(ss0, col, '\t')) {
            if (col == "student_id") idx_studentId = i;
            else if (col == "student_name") idx_studentName = i;
            else if (col == "class_id") idx_classId = i;
            else if (col == "class_name") idx_className = i;
            else if (col == "course_id") idx_courseId = i;
            else if (col == "course_name") idx_courseName = i;
            else if (col == "score") idx_score = i;
            ++i;
        }
    }
    LOGV("[getAllQueryInputsNative] 列索引 studentId=%d, studentName=%d, classId=%d, className=%d, courseId=%d, courseName=%d, score=%d",
         idx_studentId, idx_studentName, idx_classId, idx_className, idx_courseId, idx_courseName, idx_score);

    // 6. 安全转换函数
    auto safeStoi = [](const std::string& s, int defaultValue = 0) -> int {
        if (s.empty()) return defaultValue;
        try { return std::stoi(s); } catch (...) { return defaultValue; }
    };
    auto safeStod = [](const std::string& s, double defaultValue = 0.0) -> double {
        if (s.empty()) return defaultValue;
        try { return std::stod(s); } catch (...) { return defaultValue; }
    };

    // 7. 创建 Java 对象数组
    jclass cls = env->FindClass("com/example/client/StudentFullInfo");
    if (!cls) {
        LOGV("[getAllQueryInputsNative] 找不到 Java 类 StudentFullInfo");
        return nullptr;
    }

    jmethodID ctor = env->GetMethodID(cls, "<init>", "(ILjava/lang/String;ILjava/lang/String;ILjava/lang/String;D)V");
    if (!ctor) {
        LOGV("[getAllQueryInputsNative] 找不到构造函数");
        return nullptr;
    }

    jobjectArray arr = env->NewObjectArray(lines.size() - 1, cls, nullptr);
    if (!arr) {
        LOGV("[getAllQueryInputsNative] 创建 Java 对象数组失败");
        return nullptr;
    }

    // 8. 遍历数据行
    for (size_t j = 1; j < lines.size(); ++j) {
        std::stringstream ss(lines[j]);
        std::vector<std::string> fieldsVec;
        std::string f;
        while (std::getline(ss, f, '\t')) fieldsVec.push_back(f);

        int studentId = (idx_studentId != -1 && idx_studentId < fieldsVec.size()) ? safeStoi(fieldsVec[idx_studentId]) : 0;
        int classId   = (idx_classId != -1 && idx_classId < fieldsVec.size()) ? safeStoi(fieldsVec[idx_classId]) : 0;
        int courseId  = (idx_courseId != -1 && idx_courseId < fieldsVec.size()) ? safeStoi(fieldsVec[idx_courseId]) : 0;
        double score  = (idx_score != -1 && idx_score < fieldsVec.size()) ? safeStod(fieldsVec[idx_score]) : 0.0;

        jstring studentName = (idx_studentName != -1 && idx_studentName < fieldsVec.size()) ? env->NewStringUTF(fieldsVec[idx_studentName].c_str()) : nullptr;
        jstring className   = (idx_className != -1 && idx_className < fieldsVec.size()) ? env->NewStringUTF(fieldsVec[idx_className].c_str()) : nullptr;
        jstring courseName  = (idx_courseName != -1 && idx_courseName < fieldsVec.size()) ? env->NewStringUTF(fieldsVec[idx_courseName].c_str()) : nullptr;

        jobject obj = env->NewObject(cls, ctor, studentId, studentName, classId, className, courseId, courseName, score);
        if (!obj) {
            LOGV("[getAllQueryInputsNative] 第 %zu 行创建对象失败", j);
            continue;
        }

        env->SetObjectArrayElement(arr, j - 1, obj);
    }

    LOGV("[getAllQueryInputsNative] 执行结束, 返回对象数组大小: %zu", lines.size() - 1);
    return arr;
}



//发包函数
extern "C"
JNIEXPORT jint JNICALL
Java_com_example_client_DbManager_sendDbRequest(JNIEnv *env, jclass clazz, jint req_type,
                                                jint table_type, jstring field_list,
                                                jstring value_list, jstring where_clause) {
    LOGV("[sendDbRequest] 开始执行, req_type=%d, table_type=%d", req_type, table_type);

    if (!field_list || !value_list) {
        LOGV("[sendDbRequest] 参数为空: field_list=%p, value_list=%p", field_list, value_list);
        return 0;
    }

    // 获取 C 字符串
    const char *cFieldList = env->GetStringUTFChars(field_list, nullptr);
    const char *cValueList = env->GetStringUTFChars(value_list, nullptr);
    const char *cWhere = where_clause ? env->GetStringUTFChars(where_clause, nullptr) : nullptr;

    LOGV("[sendDbRequest] 字符串获取成功: fields=%s, values=%s, where=%s",
         cFieldList, cValueList, cWhere ? cWhere : "NULL");

    // 构造请求包
    DbRequestPkg pkg{};
    pkg.m_ReqType = req_type;
    pkg.m_TableType = table_type;
    strncpy(pkg.m_FieldList, cFieldList, sizeof(pkg.m_FieldList) - 1);
    strncpy(pkg.m_ValueList, cValueList, sizeof(pkg.m_ValueList) - 1);
    if (cWhere) strncpy(pkg.m_WhereClause, cWhere, sizeof(pkg.m_WhereClause) - 1);

    // 释放 JNI 字符串
    env->ReleaseStringUTFChars(field_list, cFieldList);
    env->ReleaseStringUTFChars(value_list, cValueList);
    if (cWhere) env->ReleaseStringUTFChars(where_clause, cWhere);

    // 建立 TCP 连接
    pthread_mutex_lock(&g_sock_mutex);
    if (g_sock_fd < 0) {
        g_sock_fd = createTcpConnection();
        if (g_sock_fd < 0) {
            LOGV("[sendDbRequest] TCP 连接失败");
            pthread_mutex_unlock(&g_sock_mutex);
            return 0;
        }
        LOGV("[sendDbRequest] TCP 连接成功, fd=%d", g_sock_fd);
    }

    // 发送请求包
    ssize_t sent = send(g_sock_fd, &pkg, sizeof(pkg), 0);
    if (sent <= 0) {
        LOGV("[sendDbRequest] 发送请求包失败, sent=%zd", sent);
        close(g_sock_fd);
        g_sock_fd = -1;
        pthread_mutex_unlock(&g_sock_mutex);
        return 0;
    }

    LOGV("[sendDbRequest] 请求包发送成功, sent=%zd, pkg_size=%zu", sent, sizeof(pkg));
    pthread_mutex_unlock(&g_sock_mutex);

    return sent == sizeof(pkg) ? 1 : 0;
}


//查询函数
extern "C"
JNIEXPORT jobjectArray JNICALL
Java_com_example_client_DbManager_queryTableNative(JNIEnv *env, jclass clazz, jint table_type,
                                                   jstring jfields, jstring jvalues) {

    LOGV("[queryTableNative] 开始执行");

    if (!jfields || !jvalues) {
        LOGV("[queryTableNative] 参数为空: jfields=%p, jvalues=%p", jfields, jvalues);
        return nullptr;
    }

    // 1. 获取 C 字符串
    const char *fields = env->GetStringUTFChars(jfields, nullptr);
    const char *values = env->GetStringUTFChars(jvalues, nullptr);
    LOGV("[queryTableNative][Step1] 获取字段和取值: fields=%s, values=%s", fields, values);

    // 2. 构造请求包
    DbRequestPkg pkg{};
    pkg.m_ReqType = REQ_QUERY;
    pkg.m_TableType = table_type;
    strncpy(pkg.m_FieldList, fields, sizeof(pkg.m_FieldList) - 1);
    strncpy(pkg.m_ValueList, values, sizeof(pkg.m_ValueList) - 1);

    env->ReleaseStringUTFChars(jfields, fields);
    env->ReleaseStringUTFChars(jvalues, values);

    // 3. 建立 TCP 连接
    pthread_mutex_lock(&g_sock_mutex);
    if (g_sock_fd < 0) {
        g_sock_fd = createTcpConnection();
        if (g_sock_fd < 0) {
            LOGV("[queryTableNative][Step3] TCP 连接创建失败");
            pthread_mutex_unlock(&g_sock_mutex);
            return nullptr;
        }
        LOGV("[queryTableNative][Step3] TCP 连接创建成功, fd=%d", g_sock_fd);
    }

    // 4. 发送请求包
    ssize_t sent = send(g_sock_fd, &pkg, sizeof(pkg), 0);
    if (sent <= 0) {
        LOGV("[queryTableNative][Step4] 发送请求包失败, sent=%zd", sent);
        close(g_sock_fd);
        g_sock_fd = -1;
        pthread_mutex_unlock(&g_sock_mutex);
        return nullptr;
    }
    LOGV("[queryTableNative][Step4] 请求包发送成功, sent=%zd", sent);
    pthread_mutex_unlock(&g_sock_mutex);

    // 5. 接收返回数据
    char buffer[8192] = {0};
    ssize_t n = recv(g_sock_fd, buffer, sizeof(buffer) - 1, 0);
    if (n <= 0) {
        LOGV("[queryTableNative][Step5] 接收数据失败, n=%zd", n);
        close(g_sock_fd);
        g_sock_fd = -1;
        return nullptr;
    }
    buffer[n] = '\0';
    close(g_sock_fd);
    g_sock_fd = -1;
    LOGV("[queryTableNative][Step5] 接收数据成功, n=%zd", n);

    // 6. 拆分行
    std::vector<std::string> lines;
    char *saveptr = nullptr;
    char *line = strtok_r(buffer, "\r\n", &saveptr);
    while (line) {
        if (strlen(line) > 0) lines.push_back(line);
        line = strtok_r(nullptr, "\r\n", &saveptr);
    }
    LOGV("[queryTableNative][Step6] 拆分数据行完成, 行数=%zu", lines.size());
    if (lines.empty()) {
        LOGV("[queryTableNative][Step6] 没有收到数据行");
        return nullptr;
    }

    // 7. 拆列，获取字段索引
    std::stringstream ss0(lines[0]);
    std::string col;
    std::vector<int> idxs(5, -1);
    int i = 0;
    while (std::getline(ss0, col, '\t')) {
        if (i < 5) idxs[i] = i;
        LOGV("[queryTableNative][Step7] 列索引: %s -> %d", col.c_str(), idxs[i]);
        ++i;
    }

    // 8. 创建 Java 类和构造函数
    jclass cls = env->FindClass("com/example/client/TableRowData");
    if (!cls) {
        LOGV("[queryTableNative][Step8] 找不到 Java 类 TableRowData");
        return nullptr;
    }

    jmethodID ctor = env->GetMethodID(cls, "<init>",
                                      "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V");
    if (!ctor) {
        LOGV("[queryTableNative][Step8] 找不到构造函数");
        return nullptr;
    }

    jobjectArray arr = env->NewObjectArray(lines.size() - 1, cls, nullptr);
    if (!arr) {
        LOGV("[queryTableNative][Step8] 创建 Java 对象数组失败");
        return nullptr;
    }

    // 9. 遍历数据行
    for (size_t j = 1; j < lines.size(); ++j) {
        std::stringstream ss(lines[j]);
        std::vector<std::string> fieldsVec;
        std::string f;
        while (std::getline(ss, f, '\t')) fieldsVec.push_back(f);

        auto getField = [&](int idx) -> std::string {
            return (idx != -1 && idx < fieldsVec.size()) ? fieldsVec[idx] : "";
        };

        LOGV("[queryTableNative][Step9] 行 %zu 数据: %s | %s | %s | %s | %s", j,
             getField(idxs[0]).c_str(), getField(idxs[1]).c_str(),
             getField(idxs[2]).c_str(), getField(idxs[3]).c_str(),
             getField(idxs[4]).c_str());

        jobject obj = env->NewObject(cls, ctor,
                                     env->NewStringUTF(getField(idxs[0]).c_str()),
                                     env->NewStringUTF(getField(idxs[1]).c_str()),
                                     env->NewStringUTF(getField(idxs[2]).c_str()),
                                     env->NewStringUTF(getField(idxs[3]).c_str()),
                                     env->NewStringUTF(getField(idxs[4]).c_str()));

        env->SetObjectArrayElement(arr, j - 1, obj);
    }

    LOGV("[queryTableNative] 执行完成，返回对象数组");
    return arr;
}


extern "C"
JNIEXPORT jboolean JNICALL
Java_com_example_client_DbManager_initConnectionNative(JNIEnv *env, jclass clazz) {
    // TODO: implement initConnectionNative()
    if (g_sock_fd != -1) return JNI_TRUE; // 已连接
    g_sock_fd = createTcpConnection();
    return g_sock_fd >= 0 ? JNI_TRUE : JNI_FALSE;
}
extern "C"
JNIEXPORT void JNICALL
Java_com_example_client_DbManager_closeConnectionNative(JNIEnv *env, jclass clazz) {
    // TODO: implement closeConnectionNative()
    if (g_sock_fd >= 0) {
        close(g_sock_fd);
        g_sock_fd = -1;
    }
}