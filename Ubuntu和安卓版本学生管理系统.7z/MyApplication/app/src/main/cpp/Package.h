#ifndef CLIENT_PACKAGE_H
#define CLIENT_PACKAGE_H

#include <cstring>

#define NAME_LEN 64
#define FIELD_STR_LEN 256
#define VALUE_STR_LEN 1024

// 操作请求类型
#define REQ_INSERT       1000
#define REQ_DELETE       1001
#define REQ_UPDATE       1002
#define REQ_QUERY        1003

// 表类型定义
#define TABLE_STUDENT          2001
#define TABLE_CLASS            2002
#define TABLE_COURSE           2003
#define TABLE_ENROLL           2004
#define TABLE_STUDENT_CLASS    2005
#define TABLE_VIEW_FULLINFO    2006

//-----------------------------------------
// 客户端发起的通用数据库请求包
struct DbRequestPkg {
    int m_ReqType = 0;
    int m_TableType = 0;
    char m_FieldList[FIELD_STR_LEN] = {0};
    char m_ValueList[VALUE_STR_LEN] = {0};
    char m_WhereClause[VALUE_STR_LEN] = {0};

    DbRequestPkg() = default;
    DbRequestPkg(int reqType, int tableType, const char* fields, const char* values, const char* where = "") {
        m_ReqType = reqType;
        m_TableType = tableType;
        if (fields) strncpy(m_FieldList, fields, sizeof(m_FieldList) - 1);
        if (values) strncpy(m_ValueList, values, sizeof(m_ValueList) - 1);
        if (where) strncpy(m_WhereClause, where, sizeof(m_WhereClause) - 1);
    }
};

//-----------------------------------------
// 服务器响应包
struct DbResponsePkg {
    int m_ReqType = 0;
    int m_TableType = 0;
    int m_IsSucceed = 0;
    int m_nResultCount = 0;

    DbResponsePkg() = default;
};

//-----------------------------------------
// 查询结果结构体
struct QueryStudentRow {
    int m_StudentID = 0;
    char m_StudentName[NAME_LEN] = {0};

    QueryStudentRow() = default;
    QueryStudentRow(int id, const char* name) : m_StudentID(id) {
        if (name) strncpy(m_StudentName, name, NAME_LEN - 1);
    }
};

struct QueryClassRow {
    int m_ClassID = 0;
    char m_ClassName[NAME_LEN] = {0};

    QueryClassRow() = default;
    QueryClassRow(int id, const char* name) : m_ClassID(id) {
        if (name) strncpy(m_ClassName, name, NAME_LEN - 1);
    }
};

struct QueryCourseRow {
    int m_CourseID = 0;
    char m_CourseName[NAME_LEN] = {0};

    QueryCourseRow() = default;
    QueryCourseRow(int id, const char* name) : m_CourseID(id) {
        if (name) strncpy(m_CourseName, name, NAME_LEN - 1);
    }
};

struct QueryEnrollRow {
    int id = 0;
    int student_id = 0;
    int course_id = 0;
    float score = 0.0f;

    QueryEnrollRow() = default;
    QueryEnrollRow(int i, int sid, int cid, float s) : id(i), student_id(sid), course_id(cid), score(s) {}
};

struct QueryStudentClassRow {
    int student_id = 0;
    int class_id = 0;

    QueryStudentClassRow() = default;
    QueryStudentClassRow(int sid, int cid) : student_id(sid), class_id(cid) {}
};

#endif //CLIENT_PACKAGE_H