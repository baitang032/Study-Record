package com.example.client;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.example.client.databinding.ActivityMainBinding;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;

public class MainActivity extends AppCompatActivity {

    private Socket socket;
    private DataInputStream input;
    private DataOutputStream output;

    // Used to load the 'client' library on application startup.
    static {
        System.loadLibrary("client");
    }

    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        DbManager.initConnectionNative();
        findViewById(R.id.btn_student).setOnClickListener(v -> openTableActivity("Student"));
        findViewById(R.id.btn_class).setOnClickListener(v -> openTableActivity("ClassInfo"));
        findViewById(R.id.btn_course).setOnClickListener(v -> openTableActivity("Course"));
        findViewById(R.id.btn_enroll).setOnClickListener(v -> openTableActivity("Enroll"));
        findViewById(R.id.btn_student_class).setOnClickListener(v -> openTableActivity("StudentClassMap"));
        findViewById(R.id.btn_query_full).setOnClickListener(v -> openTableActivity("StudentFullInfo"));
    }

    private void openTableActivity(String tableName) {
        Intent intent = new Intent(this, TableActivity.class);
        intent.putExtra("tableName", tableName);
        startActivity(intent);
    }




    /**
     * A native method that is implemented by the 'client' native library,
     * which is packaged with this application.
     */
    public native String stringFromJNI();


    @Override
    protected void onDestroy() {
        DbManager.closeConnectionNative();
        super.onDestroy();
    }
}