package com.example.client;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.example.client.DbConstants;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.net.CookieHandler;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.example.client.R;
public class TableActivity extends AppCompatActivity  {

    private RecyclerView recyclerView;
    private int tableType;
    private TableAdapter adapter;
    private String tableName;
    private ProgressBar progressBar;
    private List<TableRowData> dataList = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_table);

        //RecyclerView 列表初始化与数据绑定
        // 1. 获取控件
        recyclerView = findViewById(R.id.rvTable);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        progressBar = findViewById(R.id.progressBar);

        // 2. 获取表名并显示
        tableName = getIntent().getStringExtra("tableName");
        ((TextView)findViewById(R.id.tvTableName)).setText(getTableFields(tableName));

        // 3. 初始化适配器并绑定
        //adapter = new TableAdapter((List<Object>) (List<?>) dataList);
        adapter = new TableAdapter(dataList);
        recyclerView.setAdapter(adapter);

        // 4. 设置长按事件
        adapter.setOnItemLongClickListener(new TableAdapter.OnItemLongClickListener() {
            @Override
            public void onItemLongClick(int position) {
                // 长按弹出菜单
                final String[] menu = {"删除", "修改"};
                AlertDialog.Builder menuBuilder = new AlertDialog.Builder(TableActivity.this);
                LinearLayout menuLayout = new LinearLayout(TableActivity.this);
                menuLayout.setOrientation(LinearLayout.VERTICAL);
                menuLayout.setPadding(50, 40, 50, 10);

                for (int i = 0; i < menu.length; i++) {
                    final int index = i;
                    Button btn = new Button(TableActivity.this);
                    btn.setText(menu[i]);
                    btn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (index == 0) { // 删除
                                AlertDialog.Builder builder = new AlertDialog.Builder(TableActivity.this);
                                builder.setTitle("确认删除");
                                builder.setMessage("确定要删除这一行吗？");

                                builder.setPositiveButton("删除", null);
                                builder.setNegativeButton("取消", null);

                                AlertDialog deleteDialog = builder.create();
                                deleteDialog.show();

                                // 手动处理点击事件
                                deleteDialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        TableRowData row = dataList.get(position);
                                        StringBuilder whereClause = new StringBuilder();

                                        // 多字段匹配规则
                                        if ("Enroll".equals(tableName)) {
                                            String[] keyFields = {"学生ID", "课程ID"};
                                            for (int i = 0; i < keyFields.length; i++) {
                                                String dbField = mapFieldName(tableName, keyFields[i]);
                                                String val = (i == 0) ? row.getField1() : row.getField2();
                                                if (i > 0) whereClause.append(" AND ");
                                                whereClause.append(dbField).append("='").append(val).append("'");
                                            }
                                        } else if ("StudentClassMap".equals(tableName)) {
                                            String[] keyFields = {"学生ID", "班级ID"};
                                            for (int i = 0; i < keyFields.length; i++) {
                                                String dbField = mapFieldName(tableName, keyFields[i]);
                                                String val = (i == 0) ? row.getField1() : row.getField2();
                                                if (i > 0) whereClause.append(" AND ");
                                                whereClause.append(dbField).append("='").append(val).append("'");
                                            }
                                        } else {
                                            String uiFieldName = getFieldsForTable(tableName)[0]; // 第一列一般是主键
                                            String dbField = mapFieldName(tableName, uiFieldName);
                                            String value = row.getField1();
                                            whereClause.append(dbField).append("='").append(value).append("'");
                                        }

                                        int tableType = getTableTypeFromName(tableName);

                                        // 异步发包删除
                                        new Thread(new Runnable() {
                                            @Override
                                            public void run() {
                                                int res = DbManager.sendDbRequest(DbConstants.REQ_DELETE,
                                                        tableType,
                                                        "", "",  // field/value 空
                                                        whereClause.toString());

                                                if (res == 1) {
                                                    runOnUiThread(new Runnable() {
                                                        @Override
                                                        public void run() {
                                                            dataList.remove(position);
                                                            adapter.notifyItemRemoved(position);
                                                            deleteDialog.dismiss();
                                                        }
                                                    });
                                                }
                                            }
                                        }).start();
                                    }
                                });

                            } else if (index == 1) { // 修改
                                showEditDialog(position);
                            }
                        }
                    });
                    menuLayout.addView(btn);
                }

                AlertDialog menuDialog = new AlertDialog.Builder(TableActivity.this)
                        .setView(menuLayout)
                        .create();
                menuDialog.show();
            }
        });



        // 1. 获取表名
        tableName = getIntent().getStringExtra("tableName");
        ((TextView)findViewById(R.id.tvTableName)).setText(getTableFields(tableName));

        // 2. 请求数据（放到线程里）
        //loadDataAsync(tableName);
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            loadDataAsync(tableName);
        }, 300);

    }

    //修改对话框
    private void showEditDialog(int position) {
        TableRowData row = dataList.get(position);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("修改记录");

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 40, 50, 10);

        String[] fields = getFieldsForTable(tableName);
        List<EditText> editTexts = new ArrayList<>();

        for (int i = 0; i < fields.length; i++) {
            EditText et = new EditText(this);
            et.setHint(fields[i]);
            // 预填当前值
            switch (i) {
                case 0: et.setText(row.getField1()); break;
                case 1: et.setText(row.getField2()); break;
                case 2: et.setText(row.getField3()); break;
                case 3: et.setText(row.getField4()); break;
            }
            layout.addView(et);
            editTexts.add(et);
        }

        builder.setView(layout);
        builder.setPositiveButton("修改", null);
        builder.setNegativeButton("取消", (dialog, which) -> dialog.dismiss());

        AlertDialog dialog = builder.create();
        dialog.show();

        // 手动处理点击
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            StringBuilder fieldList = new StringBuilder();
            StringBuilder valueList = new StringBuilder();
            StringBuilder whereClause = new StringBuilder();

            for (int i = 0; i < fields.length; i++) {
                String dbField = mapFieldName(tableName, fields[i]);
                String newValue = editTexts.get(i).getText().toString();
                String oldValue = null;

                switch (i) {
                    case 0: oldValue = row.getField1(); break;
                    case 1: oldValue = row.getField2(); break;
                    case 2: oldValue = row.getField3(); break;
                    case 3: oldValue = row.getField4(); break;
                }

                if (i > 0) {
                    fieldList.append(",");
                    valueList.append(",");
                }
                fieldList.append(dbField);
                valueList.append(newValue);

                // 构建 whereClause 精准匹配原值
                if (oldValue != null && !oldValue.isEmpty()) {
                    if (whereClause.length() > 0) whereClause.append(" AND ");
                    whereClause.append(dbField).append("='").append(oldValue).append("'");
                }
            }

            int tableType = getTableTypeFromName(tableName);

            new Thread(() -> {
                int res = DbManager.sendDbRequest(DbConstants.REQ_UPDATE,
                        tableType,
                        fieldList.toString(),
                        valueList.toString(),
                        whereClause.toString());

                if (res == 1) {
                    runOnUiThread(() -> {
                        //loadDataAsync(tableName);
                        new Handler(Looper.getMainLooper()).postDelayed(() -> {
                            loadDataAsync(tableName);
                        }, 300);
                        dialog.dismiss();
                    });
                }
            }).start();
        });
    }


    // 菜单加载
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_table, menu); // 加载menu_table.xml
        return true;
    }
    // 菜单点击事件
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_add) {
            showAddDialog();   // 自定义方法，根据表类型生成输入框
            return true;
        } else if (id == R.id.action_query) {
            showQueryDialog(); // 自定义方法
            return true;
        } else if(id==R.id.action_refresh){
            refreshTableData();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    // 重新加载数据并刷新 RecyclerView
//    private void refreshTableData() {
//        List<Object> dataList = loadData(tableName); // 重新调用 JNI 或网络接口
//        adapter.updateData(dataList); // 使用 TableAdapter 里新增的 updateData 方法
//    }

    private void refreshTableData() {
        List<TableRowData> newData = loadData(tableName); // 重新调用 JNI 或网络接口，返回 TableRowData 列表
        adapter.updateData(newData); // 使用 TableAdapter 里的 updateData 方法
    }

    // 添加记录对话框
    private void showAddDialog() {
        // 1. 创建 AlertDialog.Builder
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("添加记录");

        // 2. 动态创建输入表单
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 40, 50, 10);

        List<EditText> editTexts = new ArrayList<>();
        String[] fields = getFieldsForTable(tableName);

        for (String field : fields) {
            EditText et = new EditText(this);
            et.setHint(field);
            layout.addView(et);
            editTexts.add(et);
        }

        builder.setView(layout);

        // 3. 设置按钮  添加功能
        builder.setPositiveButton("添加", null); // 先传 null
        builder.setNegativeButton("取消", (dialog, which) -> dialog.dismiss());

        AlertDialog dialog = builder.create();
        dialog.show();

        // 4. 手动处理 PositiveButton 点击
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            StringBuilder fieldList = new StringBuilder();
            StringBuilder valueList = new StringBuilder();
            for (int i = 0; i < fields.length; i++) {
                String val = editTexts.get(i).getText().toString();
                String dbField = mapFieldName(tableName, fields[i]);
                if (i > 0) {
                    fieldList.append(",");
                    valueList.append(",");
                }
                fieldList.append(dbField);
                valueList.append(val);
            }

            int tableType = getTableTypeFromName(tableName);

            // 异步发送请求
            new Thread(() -> {
                int res = DbManager.sendDbRequest(DbConstants.REQ_INSERT, tableType,
                        fieldList.toString(), valueList.toString(), "");

                // 成功后刷新 UI
                if (res == 1) {
                    runOnUiThread(() -> {
                        //loadDataAsync(tableName);
                        new Handler(Looper.getMainLooper()).postDelayed(() -> {
                            loadDataAsync(tableName);
                        }, 300);
                        dialog.dismiss(); // 只有发送成功后再关闭对话框
                    });
                }
            }).start();
        });
    }


//查询对话框
    //对话框内容
    private void showQueryDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("查询记录");

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 40, 50, 10);

        List<EditText> editTexts = new ArrayList<>();
        String[] fields = getFieldsForTable(tableName); // 根据表名获取字段名

        for (String field : fields) {
            EditText et = new EditText(this);
            et.setHint("输入 " + field + " 或留空查询全部");
            layout.addView(et);
            editTexts.add(et);
        }

        builder.setView(layout);

        builder.setPositiveButton("查询", null); // 先传 null
        builder.setNegativeButton("取消", (dialog, which) -> dialog.dismiss());

        AlertDialog dialog = builder.create();
        dialog.show();

        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            List<String> fieldList = new ArrayList<>();
            List<String> valueList = new ArrayList<>();

            for (int i = 0; i < fields.length; i++) {
                String val = editTexts.get(i).getText().toString().trim();
                if (!val.isEmpty()) { // 只处理非空输入
                    fieldList.add(mapFieldName(tableName, fields[i]));
                    valueList.add(val);
                }
            }

            if (fieldList.isEmpty()) {
                Toast.makeText(TableActivity.this, "请至少输入一个查询条件", Toast.LENGTH_SHORT).show();
                return;
            }

            String fieldsStr = TextUtils.join(",", fieldList);
            String valuesStr = TextUtils.join(",", valueList);

            int tableType = getTableTypeFromName(tableName);

            new Thread(() -> {
                List<TableRowData> result = DbManager.queryTable(
                        tableType,
                        fieldsStr,
                        valuesStr
                );

                runOnUiThread(() -> {
                    dataList.clear();
                    dataList.addAll(result);
                    adapter.notifyDataSetChanged();
                    dialog.dismiss();
                });
            }).start();
        });
    }





    // 根据表名返回字段
    private String[] getFieldsForTable(String tableName) {
        switch (tableName) {
            case "Student": return new String[]{"学号","姓名"};
            case "ClassInfo": return new String[]{"班级ID","班级名称"};
            case "Course": return new String[]{"课程ID","课程名称"};
            case "Enroll": return new String[]{"学生ID","课程ID","成绩"};
            case "StudentClassMap": return new String[]{"学生ID","班级ID"};
            case "StudentFullInfo": return new String[]{"学生姓名","班级名称","课程名称","成绩"};
            default: return new String[]{};
        }
    }

    private String getTableFields(String tableName) {
        switch (tableName) {
            case "Student": return "学号\t姓名";
            case "ClassInfo": return "班级ID\t班级名称";
            case "Course": return "课程ID\t课程名称";
            case "Enroll": return "学生ID\t课程ID\t成绩";
            case "StudentClassMap": return "学生ID\t班级ID";
            case "StudentFullInfo": return "学生姓名\t班级名称\t课程名称\t成绩";
            default: return tableName;
        }
    }

    //静态映射表，用来把表名字符串（比如 "Student", "Course"）映射成定义的表类型常量
    private static final Map<String, Integer> TABLE_TYPE_MAP = new HashMap<>();
    static {
        TABLE_TYPE_MAP.put("Student", DbConstants.TABLE_STUDENT);
        TABLE_TYPE_MAP.put("ClassInfo", DbConstants.TABLE_CLASS);
        TABLE_TYPE_MAP.put("Course", DbConstants.TABLE_COURSE);
        TABLE_TYPE_MAP.put("Enroll", DbConstants.TABLE_ENROLL);
        TABLE_TYPE_MAP.put("StudentClassMap", DbConstants.TABLE_STUDENT_CLASS);
        TABLE_TYPE_MAP.put("StudentFullInfo", DbConstants.TABLE_VIEW_FULLINFO);
    }

    private int getTableTypeFromName(String tableName) {
        Integer type = TABLE_TYPE_MAP.get(tableName);
        return type != null ? type : -1;
    }
    private String mapFieldName(String tableName, String uiFieldName) {
        switch (tableName) {
            case "Student":
                if (uiFieldName.equals("学号")) return "id";
                if (uiFieldName.equals("姓名")) return "name";
                break;
            case "ClassInfo":
                if (uiFieldName.equals("班级ID")) return "id";
                if (uiFieldName.equals("班级名称")) return "name";
                break;
            case "Course":
                if (uiFieldName.equals("课程ID")) return "id";
                if (uiFieldName.equals("课程名称")) return "name";
                break;
            case "Enroll":
                if (uiFieldName.equals("学生ID")) return "student_id";
                if (uiFieldName.equals("课程ID")) return "course_id";
                if (uiFieldName.equals("成绩")) return "score";
                break;
            case "StudentClassMap":
                if (uiFieldName.equals("学生ID")) return "student_id";
                if (uiFieldName.equals("班级ID")) return "class_id";
                break;
            case "StudentFullInfo":
                if (uiFieldName.equals("学号")) return "student_id";
                if (uiFieldName.equals("学生姓名")) return "student_name";
                if (uiFieldName.equals("班级编号")) return "class_id";
                if (uiFieldName.equals("班级名称")) return "class_name";
                if (uiFieldName.equals("课程编号")) return "course_id";
                if (uiFieldName.equals("课程名称")) return "course_name";
                if (uiFieldName.equals("成绩")) return "score";
                break;
        }
        return uiFieldName; // 默认原样返回
    }


    // 异步加载数据
//    private void loadDataAsync(String tableName) {
//        progressBar.setVisibility(View.VISIBLE);
//        recyclerView.setVisibility(View.GONE);
//
//        new Thread(() -> {
//            List<Object> dataList = loadData(tableName);
//
//            runOnUiThread(() -> {
//                adapter = new TableAdapter(dataList);
//                recyclerView.setAdapter(adapter);
//
//                progressBar.setVisibility(View.GONE);
//                recyclerView.setVisibility(View.VISIBLE);
//            });
//        }).start();
//    }
    private void loadDataAsync(String tableName) {
        progressBar.setVisibility(View.VISIBLE);
        recyclerView.setVisibility(View.GONE);

        new Thread(() -> {
            List<TableRowData> newData = loadData(tableName); // 返回 TableRowData 列表

            runOnUiThread(() -> {
                adapter.updateData(newData);

                progressBar.setVisibility(View.GONE);
                recyclerView.setVisibility(View.VISIBLE);
            });
        }).start();
    }





    /** 根据表名调用不同 JNI 方法 */
//    private List<Object> loadData(String tableName){
//        List<Object> list = new ArrayList<>();
//        switch(tableName){
//            case "Student": list.addAll(getAllStudents()); break;
//            case "ClassInfo": list.addAll(getAllClasses()); break;
//            case "Course": list.addAll(getAllCourses()); break;
//            case "Enroll": list.addAll(getAllEnrolls()); break;
//            case "StudentClassMap": list.addAll(getAllStudentClasses()); break;
//            case "StudentFullInfo": list.addAll(getAllQueryInputs()); break;
//        }
//        return list;
//    }

    /*
    * switch "Student" → 设置 tableType = TABLE_STUDENT
               → 调用 getAllStudents()
               → 遍历每个 Student 转成 TableRowData
               → 返回 list 给适配器显示
    * */
    private List<TableRowData> loadData(String tableName) {
        List<TableRowData> list = new ArrayList<>();
        switch (tableName) {
            case "Student":
                tableType = DbConstants.TABLE_STUDENT;
                for (Student s : getAllStudents()) {
                    list.add(new TableRowData(
                            String.valueOf(s.getId()),  // field1
                            s.getName(),                // field2
                            "",                         // field3
                            "",                         // field4
                            ""                          // field5
                    ));
                }
                break;

            case "ClassInfo":
                tableType = DbConstants.TABLE_CLASS;
                for (Class c : getAllClasses()) {
                    list.add(new TableRowData(
                            String.valueOf(c.getId()),
                            c.getName(),
                            "",
                            "",
                            ""
                    ));
                }
                break;

            case "Course":
                tableType = DbConstants.TABLE_COURSE;
                for (Course c : getAllCourses()) {
                    list.add(new TableRowData(
                            String.valueOf(c.getId()),
                            c.getName(),
                            "",
                            "",
                            ""
                    ));
                }
                break;

            case "Enroll":
                tableType = DbConstants.TABLE_ENROLL;
                for (Enroll e : getAllEnrolls()) {
                    list.add(new TableRowData(
                            String.valueOf(e.getStudentId()),
                            String.valueOf(e.getCourseId()),
                            String.valueOf(e.getScore()),
                            "",
                            ""
                    ));
                }
                break;

            case "StudentClassMap":
                tableType = DbConstants.TABLE_STUDENT_CLASS;
                for (StudentClassMap scm : getAllStudentClasses()) {
                    list.add(new TableRowData(
                            String.valueOf(scm.getStudentId()),
                            String.valueOf(scm.getClassId()),
                            "",
                            "",
                            ""
                    ));
                }
                break;

            case "StudentFullInfo":
                tableType = DbConstants.TABLE_VIEW_FULLINFO;
                for (StudentFullInfo sfi : getAllQueryInputs()) {
                    list.add(new TableRowData(
                            sfi.getStudentName(),
                            sfi.getClassName(),
                            sfi.getCourseName(),
                            String.valueOf(sfi.getScore()),
                            ""  // field5，如果将来有第五个字段可以填
                    ));
                }
                break;
        }

        return list;
    }






    // ---------- JNI 方法 ----------
    public native Student[] getAllStudentsNative();
    public List<Student> getAllStudents() { return new ArrayList<>(Arrays.asList(getAllStudentsNative())); }

    public native Class[] getAllClassesNative();
    public List<Class> getAllClasses() { return new ArrayList<>(Arrays.asList(getAllClassesNative())); }

    public native Course[] getAllCoursesNative();
    public List<Course> getAllCourses() { return new ArrayList<>(Arrays.asList(getAllCoursesNative())); }

    public native Enroll[] getAllEnrollsNative();
    public List<Enroll> getAllEnrolls() { return new ArrayList<>(Arrays.asList(getAllEnrollsNative())); }

    public native StudentClassMap[] getAllStudentClassesNative();
    public List<StudentClassMap> getAllStudentClasses() { return new ArrayList<>(Arrays.asList(getAllStudentClassesNative())); }

    public native StudentFullInfo[] getAllQueryInputsNative();
    public List<StudentFullInfo> getAllQueryInputs() { return new ArrayList<>(Arrays.asList(getAllQueryInputsNative())); }
}

