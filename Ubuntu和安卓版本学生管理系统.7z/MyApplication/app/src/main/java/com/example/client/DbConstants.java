package com.example.client;
public class DbConstants {
    // 操作请求类型
    public static final int REQ_INSERT = 1000;
    public static final int REQ_DELETE = 1001;
    public static final int REQ_UPDATE = 1002;
    public static final int REQ_QUERY  = 1003;

    // 表类型定义
    public static final int TABLE_STUDENT         = 2001;
    public static final int TABLE_CLASS           = 2002;
    public static final int TABLE_COURSE          = 2003;
    public static final int TABLE_ENROLL          = 2004;
    public static final int TABLE_STUDENT_CLASS   = 2005;
    public static final int TABLE_VIEW_FULLINFO   = 2006;

}

