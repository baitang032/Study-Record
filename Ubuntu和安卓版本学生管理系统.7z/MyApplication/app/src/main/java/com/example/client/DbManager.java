package com.example.client;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DbManager {

    static {
        System.loadLibrary("client"); // 你的 JNI 库名
    }

    public static native int sendDbRequest(
            int reqType,
            int tableType,
            String fieldList,
            String valueList,
            String whereClause
    );


    // 查询接口

    public static List<TableRowData> queryTable(int tableType, String fields, String values) {
        // 调用 JNI
        TableRowData[] arr = queryTableNative(tableType, fields, values);
        if (arr == null) return new ArrayList<>();
        return new ArrayList<>(Arrays.asList(arr));
    }

    // 对应 JNI 方法
    public static native TableRowData[] queryTableNative(int tableType, String fields, String values);

    // 初始化连接
    public static native boolean initConnectionNative();

    // 关闭连接
    public static native void closeConnectionNative();


}