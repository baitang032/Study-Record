package com.example.client;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class TableAdapter extends RecyclerView.Adapter<TableAdapter.ViewHolder> {

    private List<TableRowData> dataList;
    private OnItemLongClickListener longClickListener;
    //初始化适配器，并把外部传进来的 dataList 保存下来，作为要显示的数据源。
    public TableAdapter(List<TableRowData> dataList) {
        this.dataList = dataList;
    }

    public interface OnItemLongClickListener {
        void onItemLongClick(int position);
    }

    public void setOnItemLongClickListener(OnItemLongClickListener listener) {
        this.longClickListener = listener;
    }

    //当 RecyclerView 需要创建新的行视图时调用
    //用 LayoutInflater 把 item_table_row.xml 转成一个 View 对象。
    //返回一个 ViewHolder，持有这个视图里的控件引用（TextView 等）。
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_table_row, parent, false);
        return new ViewHolder(view);
    }

    //把 dataList 中第 position 条数据绑定到 ViewHolder 上
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        TableRowData row = dataList.get(position);

        // 设置文本
        holder.tvField1.setText(row.getField1() != null ? row.getField1() : "");
        holder.tvField2.setText(row.getField2() != null ? row.getField2() : "");
        holder.tvField3.setText(row.getField3() != null ? row.getField3() : "");
        holder.tvField4.setText(row.getField4() != null ? row.getField4() : "");
        holder.tvField5.setText(row.getField5() != null ? row.getField5() : "");

        // 控制可见性，如果没有值可以隐藏
        holder.tvField1.setVisibility(TextUtils.isEmpty(row.getField1()) ? View.GONE : View.VISIBLE);
        holder.tvField2.setVisibility(TextUtils.isEmpty(row.getField2()) ? View.GONE : View.VISIBLE);
        holder.tvField3.setVisibility(TextUtils.isEmpty(row.getField3()) ? View.GONE : View.VISIBLE);
        holder.tvField4.setVisibility(TextUtils.isEmpty(row.getField4()) ? View.GONE : View.VISIBLE);
        holder.tvField5.setVisibility(TextUtils.isEmpty(row.getField5()) ? View.GONE : View.VISIBLE);

        holder.itemView.setOnLongClickListener(v -> {
            if (longClickListener != null) {
                longClickListener.onItemLongClick(position);
            }
            return true;
        });
    }

    //告诉 RecyclerView 当前有多少条数据要显示
    @Override
    public int getItemCount() {
        return dataList.size();
    }

    //持有每一行的控件引用，避免频繁调用 findViewById 提高性能
    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvField1;
        TextView tvField2;
        TextView tvField3;
        TextView tvField4;
        TextView tvField5;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvField1 = itemView.findViewById(R.id.tvField1);
            tvField2 = itemView.findViewById(R.id.tvField2);
            tvField3 = itemView.findViewById(R.id.tvField3);
            tvField4 = itemView.findViewById(R.id.tvField4);
            tvField5 = itemView.findViewById(R.id.tvField5);
        }
    }

    public void updateData(List<TableRowData> newData) {
        dataList.clear();
        dataList.addAll(newData);
        notifyDataSetChanged();
    }
}
